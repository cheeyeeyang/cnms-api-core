<?php

namespace DoctrineTest\InstantiatorTestAsset;

enum SimpleEnumAsset
{
    case Foo;
    case Bar;
}
