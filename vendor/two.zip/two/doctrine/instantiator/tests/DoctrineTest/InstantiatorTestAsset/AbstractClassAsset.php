<?php

namespace DoctrineTest\InstantiatorTestAsset;

/**
 * A simple asset for an abstract class
 */
abstract class AbstractClassAsset
{
}
