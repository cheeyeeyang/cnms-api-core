<?php

namespace DoctrineTest\InstantiatorTestAsset;

/**
 * A simple trait with no attached logic
 */
trait SimpleTraitAsset
{
}
