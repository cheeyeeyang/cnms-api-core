<?php return array (
  'backend.appointmentoffplan.appointmentoffplan' => 'App\\Http\\Livewire\\Backend\\Appointmentoffplan\\Appointmentoffplan',
  'backend.auth.login-component' => 'App\\Http\\Livewire\\Backend\\Auth\\LoginComponent',
  'backend.auth.logout-component' => 'App\\Http\\Livewire\\Backend\\Auth\\LogoutComponent',
  'backend.dashboard-component' => 'App\\Http\\Livewire\\Backend\\DashboardComponent',
  'backend.setting.appointment-component' => 'App\\Http\\Livewire\\Backend\\Setting\\AppointmentComponent',
  'backend.setting.detail-add-appointment-component' => 'App\\Http\\Livewire\\Backend\\Setting\\DetailAddAppointmentComponent',
  'backend.setting.detail-appointment-component' => 'App\\Http\\Livewire\\Backend\\Setting\\DetailAppointmentComponent',
  'backend.setting.employee-component' => 'App\\Http\\Livewire\\Backend\\Setting\\EmployeeComponent',
  'backend.setting.promotion-component' => 'App\\Http\\Livewire\\Backend\\Setting\\PromotionComponent',
  'backend.setting.question-component' => 'App\\Http\\Livewire\\Backend\\Setting\\QuestionComponent',
  'backend.setting.role-component' => 'App\\Http\\Livewire\\Backend\\Setting\\RoleComponent',
  'backend.setting.user-component' => 'App\\Http\\Livewire\\Backend\\Setting\\UserComponent',
);