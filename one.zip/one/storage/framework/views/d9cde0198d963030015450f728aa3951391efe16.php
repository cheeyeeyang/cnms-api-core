<div>
    <div>
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">ຈັດການຂໍ້ມູນແຜນນັດໝາຍ</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                            <li class="breadcrumb-item active">ຂໍ້ມູນແຜນນັດໝາຍ</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <!--customers -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <?php if($this->selectData == 'true'): ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('admin.detailappointment')); ?>" class="btn btn-primary"><i
                                            class="fa fa-plus-circle"></i> ເພີ່ມແຜນນັດໝາຍ</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <label for="">ຄົ້ນຫາ</label>
                                        <input type="text" class="form-control" wire:model="search"
                                            placeholder="ຊື່ ຫຼື ເບີໂທ">
                                    </div>
                                </div>
                                <div class="col-md-2 mt-2">
                                    <div class="form-group">
                                        <label for="">ສະຖານະ</label>
                                        <select class="form-control" wire:model="status">
                                             <option value="">ເລືອກ</option>
                                            <option value="1">ພົບລູກຄ້າແລ້ວ</option>
                                            <option value="2">ຍັງບໍ່ໄດ້ພົບລູກຄ້າ</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                    <thead class="bg-info">
                                        <tr>
                                            <th style="text-align: center">ລ/ດ</th>
                                            <th>ພະນັກງານ</th>
                                            <th>ເບີໂທ</th>
                                            <th>ລູກຄ້າ</th>
                                            <th>ເບີໂທລູກຄ້າ</th>
                                            <th style="text-align: center">ວັນທີນັດໝາຍ</th>
                                            <th style="text-align: center">ເວລາເລີ່ມສົນທະນາ</th>
                                            <th style="text-align: center">ເວລາສິ້ນສຸດສົນທະນາ</th>
                                            <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php if(!empty($item->DATETIME_STRAT) && !empty($item->DATETIME_END)): ?>
                                            <td style="text-align: center"><i
                                                    class="fa fa-check-circle text-success"></i><?php echo e($i++); ?></td>
                                            <td class="text-success">
                                                <?php echo e($item->title); ?>

                                                <?php echo e($item->firstname); ?>

                                                <?php echo e($item->lastname); ?>

                                            </td>
                                            <?php else: ?>
                                            <td style="text-align: center"><?php echo e($i++); ?></td>
                                            <td>
                                                <?php echo e($item->title); ?>

                                                <?php echo e($item->firstname); ?>

                                                <?php echo e($item->lastname); ?>

                                            </td>
                                            <?php endif; ?>
                                            <td>
                                                <?php echo e($item->em_phone); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->c_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->c_phone); ?>

                                            </td>
                                            <?php if(!empty($item->DATETIME_STRAT) && !empty($item->DATETIME_END)): ?>
                                            <td style="text-align: center" class="text-success">
                                                <?php echo e(date('d/m/Y H:i:s', strtotime($item->DATETIME))); ?></td>
                                            <?php else: ?>
                                            <td style="text-align: center" class="text-danger">
                                                <?php echo e(date('d/m/Y H:i:s', strtotime($item->DATETIME))); ?></td>
                                            <?php endif; ?>
                                            <td style="text-align: center">
                                                <?php echo e($item->DATETIME_STRAT); ?></td>
                                            <td style="text-align: center">
                                                <?php echo e($item->DATETIME_END); ?></td>
                                            <td class="text-center">
                                                <a href="#" class="btn btn-success btn-sm"
                                                    wire:click="showLocation('<?php echo e($item->APMID); ?>')"> <i
                                                        class="fa fa-eye text-white"></i></a>
                                                <a href="#" class="btn btn-warning btn-sm"
                                                    wire:click="showUpdate(<?php echo e($item->APMID); ?>)"><i
                                                        class="fa fa-edit"></i></a>
                                                <a href="#" class="btn btn-danger btn-sm"
                                                    wire:click='delete(<?php echo e($item->APMID); ?>)'
                                                    onclick="return confirm('ທ່ານຕ້ອງການລຶບລາຍການນີ້ບໍ ？') || event.stopImmediatePropagation()"><i
                                                        class="fa fa-times"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row justify-content-center">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                        <?php else: ?>
                        <form>
                            <div class="row">
                                <h4 class="text-primary">ແກ້ໄຂແຜນັດໝາຍ</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">ຄໍາຖາມ</label>
                                        <?php $__currentLoopData = $this->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!empty($item->QUESTIONID)): ?>
                                        <div class="d-flex flex-row">
                                            <a href="#" wire:click="Deleteq(<?php echo e($item->QUESTIONID); ?>)"><i
                                                    class="fa fa-times text-danger"></i></a>&nbsp;
                                            <?php echo e($item->QUESTION); ?>

                                            <!-- <input type="checkbox" value="<?php echo e($item->QUESTIONID); ?>"
                                                wire:model="question" />&nbsp;<h5>
                                                <?php echo e($item->QUESTION); ?></h5> -->
                                        </div>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="">ຄໍາຖາມອື່ນໆ</label>
                                        <textarea wire:model="admin_question" placeholder="ຄໍາຖາມອື່ນໆ ..." rows="3"
                                            cols="50" class="form-control">
                                    </textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span>ພະນັກງານ</label>
                                        <select class="form-control" wire:model="emp_id">
                                            <option value="">ເລືອກ</option>
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->EMPID); ?>"><?php echo e($item->TITLE); ?> <?php echo e($item->FNAME); ?>

                                                <?php echo e($item->LNAME); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['emp_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ວັນທີນັດໝາຍ</label>
                                        <input type="datetime-local" class="form-control" placeholder="ນາມສະກຸນ"
                                            wire:model="date">
                                        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> Lat</label>
                                        <input type="text" class="form-control" placeholder="Lat" wire:model="lat">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> Long</label>
                                        <input type="text" class="form-control" placeholder="Long" wire:model="long">
                                    </div>
                                </div>
                            </div>
                            <div class="row justify-content-center">
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-warning btn-block" wire:click="back"><i
                                            class="fa fa-undo" aria-hidden="true"></i>&nbsp;ກັບຄືນ</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-success btn-block" wire:click="edit"><i
                                            class="fas fa-pen"></i>&nbsp;ແກ້ໄຂ</button>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- /.modal-location -->
            <div wire:ignore.self class="modal fade" id="modal-location">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title text-primary"><u>ແຜນນັດໝາຍ?</u></h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p class="text-center text-danger">
                                <i class="fa fa-clock"></i> ວັນທີນັດໝາຍ: <?php echo e(date('d/m/Y H:i:s', strtotime($this->date))); ?>

                            </p>
                            <p>ພະນັກງານ: <?php echo e($this->emp_fullname); ?></p>
                            <p>ລູກຄ້າ: <?php echo e($this->client_fullname); ?></p>
                            <div class="row">
                            <?php if(!empty($this->lat) && !empty($this->long) && !empty($this->lat_app) && !empty($this->lng_app)): ?>
                                <div class="col-md-6">
                                    <div class="bg-light p-30 mb-30">
                                      
                                        <div class="text-center p-2">
                                            <iframe
                                                src="https://maps.google.com/maps?q=<?php echo e($this->lat); ?>,<?php echo e($this->long); ?>&hl=es;z=13&output=embed"
                                                style="width:100%;height:300px;"></iframe>
                                        </div>
                                        <p class="text-danger">ຈຸດນັດພົບລູກຄ້າ</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="bg-light p-30 mb-30">
                                        <div class="text-center p-2">
                                            <iframe
                                                src="https://maps.google.com/maps?q=<?php echo e($this->lat_app); ?>,<?php echo e($this->lng_app); ?>&hl=es;z=13&output=embed"
                                                style="width:100%;height:300px;"></iframe>
                                        </div>
                                        <p class="text-success">ຈຸດພົບລູກຄ້າ</p>
                                    </div>
                                </div>
                                <?php elseif(!empty($this->lat) && !empty($this->long) && empty($this->lat_app) && empty($this->lng_app)): ?>
                                <div class="col-md-12">
                                    <div class="bg-light p-30 mb-30">
                                      
                                        <div class="text-center p-2">
                                            <iframe
                                                src="https://maps.google.com/maps?q=<?php echo e($this->lat); ?>,<?php echo e($this->long); ?>&hl=es;z=13&output=embed"
                                                style="width:100%;height:300px;"></iframe>
                                        </div>
                                        <p class="text-danger">ຈຸດນັດພົບລູກຄ້າ</p>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center">ລ/ດ</th>
                                            <th>ຄໍາຖາມ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $this->data_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $answer = DB::table('conversation__details')->where('APMDTID',
                                        $item->APMDTID)->first();
                                        ?>
                                        <tr>
                                            <td style="text-align: center"><?php echo e($i++); ?></td>
                                            <td>
                                                <?php if(!empty($item->question->QUESTION)): ?>
                                                <p><?php echo e($item->question->QUESTION); ?></p>
                                                <?php endif; ?>
                                                <?php if(!empty($item->ANOTHER_ADMIN)): ?>
                                                <p class="text-danger">Admin: <?php echo e($item->ANOTHER_ADMIN); ?></p>
                                                <?php endif; ?>
                                                <?php if(!empty($item->ANOTHER_EMP)): ?>
                                                <p class="text-primary">ພະນັກງານ: <?php echo e($item->ANOTHER_EMP); ?></p>
                                                <?php endif; ?>
                                                <?php if(!empty($answer->ANSWER)): ?>
                                                <p class="text-success">ຄໍາຕອບ: <?php echo e($answer->ANSWER); ?></p>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
        //show location
        window.addEventListener('show-modal-location', event => {
            $('#modal-location').modal('show');
        })
        window.addEventListener('hide-modal-location', event => {
            $('#modal-location').modal('hide');
        })
        </script>
        <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/setting/appointment-component.blade.php ENDPATH**/ ?>