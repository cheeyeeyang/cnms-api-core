<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-primary card-outline">
            <div class="card-header text-center">
               <h4><b>ເລືອກວິຊາ</b></h4>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລໍາດັບ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດຫ້ອງ</th>
                    <th style="text-align: center">ຊ/ມ</th>
                    <th style="text-align: center">ປະເພດຊ/ມ</th>
                    <th style="text-align: center">ຫ້ອງ</th>
                    <th style="text-align: center">ເລືອກ</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->where('STTID', 1)->orderBy('memos.MMID', 'desc')->get();
                    ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->subject->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->subject->CREDIT); ?></td>
                        <td><?php echo e($item->classroom->classroomtype->NAME); ?></td>
                        <td style="text-align: center">
                              <?php if($item->time->TIME =='8:00-9:45'): ?>
                              1
                              <?php elseif($item->time->TIME =='10:00-11:30'): ?>
                              2
                              <?php elseif($item->time->TIME =='13:00-14:45'): ?>
                              3
                              <?php elseif($item->time->TIME =='15:00-16:30'): ?>
                              4
                              <?php endif; ?>
                        </td>
                        <td style="text-align: center"><?php echo e($item->time->REMARK); ?></td>
                        <td style="text-align: center">
                            <?php if(!empty($item->group->Group)): ?>
                                <?php echo e($item->group->Group); ?>

                            <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                            <a href="<?php echo e(route('teacher.detailstudent', ['slug' => $item->TBID])); ?>" class="btn btn-success btn-sm"><u>ເລືອກ</u></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/teacher/student-component.blade.php ENDPATH**/ ?>