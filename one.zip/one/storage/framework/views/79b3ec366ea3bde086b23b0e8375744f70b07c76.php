<div>
<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><u>ກວດກາການຂຶ້ນຫ້ອງສອນຕາມສາຍວິຊາຂອງພາກວິຊາ <?php echo e(auth()->user()->staff->department->DEPTNAME); ?></u></h5>
            </div>
            <div class="card-body">
            <div class="text-right">
                <a href="#" class="btn btn-success" id="ExportToExcel"><i class="fas fa-file"></i>&nbsp;Excel</a>
                <a href="#" class="btn btn-primary" id="btn-print"><i class="fas fa-print"></i>&nbsp;ປຣິ່ນ</a>
            </div>
              <div class="row">
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກພາກຮຽນ</label>
                             <select class="form-control" wire:model="SEMESTER">
                                  <option value="1">ພາກຮຽນ I</option>
                                  <option value="2">ພາກຮຽນ II</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ສົກຮຽນ</label>
                             <select id="" wire:model="acyear" class="form-control <?php $__errorArgs = ['acyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                             <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->ACNAME); ?>"><?php echo e($item->ACNAME); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                         </div>
                    </div>
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for="">ເລືອກສາຂາ</label>
                             <select class="form-control" wire:model="COURSEID" id="selectcourse">
                                <option value="">ເລືອກ</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->COURSEID); ?>"><?php echo e($item->COURSENAME); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                         </div>
                    </div>
               </div>
              <div class="table-responsive mt-2">
              <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດຫ້ອງ</th>
                    <th style="text-align: center">ປີຮຽນ</th>
                    <th style="text-align: center">ຫ້ອງ</th>
                    <th>ສາຂາ</th>
                    <th>ຈ/ນຊ/ມຂຶ້ນສອນແລ້ວ</th>
                    <th>ຈ/ນຊ/ມຍັງຕ້ອງຂຶ້ນສອນ</th>
                    <th style="text-align: center">ຊື່ ແລະ ນາມສະກຸນອາຈານ</th>
                    <th>ໝາຍເຫດ</th>

                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                    ?> 
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->orderBy('memos.MMID', 'desc')->where('STTID', 1)->get();
                    $active_hour = 0;
                    foreach($memos as $items){
                        $active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                    }
                    ?>
                    <?php if($active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->CREDIT); ?></td>
                        <td><?php echo e($item->classroomtypename); ?></td>
                        <td style="text-align: center"><?php echo e($item->YLEVEL); ?></td>
                        <td><?php echo e($item->Group); ?></td>
                        <td><?php echo e($item->COURSENAME); ?></td>
                        <td style="text-align: center"><a href="#" wire:click="ShowDetail(<?php echo e($item->TBID); ?>)"><?php echo e(number_format($active_hour)); ?>/<?php echo e(number_format($item->NUMBER_HOUR)); ?></a></td>
                        <td style="text-align: center"><?php echo e(number_format($item->NUMBER_HOUR - $active_hour)); ?></td>
                        <td ><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></td>
                        <td >
                            <?php if(number_format($item->NUMBER_HOUR - $active_hour) == 0): ?>
                              ສອນເຕັມ
                            <?php elseif(number_format($item->NUMBER_HOUR - $active_hour) > 0): ?>
                                ສອນບໍ່ເຕັມ
                            <?php else: ?>
                               ສອນເກີນ
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
            </div>
            <div class="d-flex justify-space-center">
                <?php echo e($timetables->links()); ?>

            </div>
            </div>
          </div>
        </div>
      </div>
       <!-- print content -->
       <div class="print-content" style="display:none;" id="page-content">
                 <div class="text-center">
                   <p>ສາທາລະນະລັດ ປະຊາທິປະໄຕ ປະຊາຊົນລາວ</p>
                   <p>ສັນຕິພາບ ເອກະລາດ ປະຊາທິປະໄຕ ເອກະພາບ ວັດທະນະຖາວອນ</p>
                 </div>
                 <div class="text-center">
                       <b><h4>ຕາຕະລາງສະຫຼຸບການປະຕິບັດຊົ່ວໂມງສອນຂອງພາກວິຊາ <?php echo e(auth()->user()->staff->department->DEPTNAME); ?> ປະຈໍາພາກຮຽນທີ <?php if($this->SEMESTER == 1): ?> I <?php else: ?> II <?php endif; ?></h4></b>
                       <b><h4> <?php if(!empty($this->acyear)): ?> ສົກຮຽນ <?php echo e($this->acyear); ?> <?php endif; ?></h4></b>
                       <?php if(!empty($this->course_name)): ?>
                           <h5>ສາຂາ: <?php echo e($this->course_name); ?></h5>
                       <?php endif; ?>
                 </div>
                 <div class="header-content-Print">
                     <div class="left">
                     </div>
                     <div class="right">
                        <h6>ວັນທີ: 02/09/2022
                     </div>
                 </div>
                <table class="report-print-content">
                <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດຫ້ອງ</th>
                    <th style="text-align: center">ປີຮຽນ</th>
                    <th style="text-align: center">ຫ້ອງ</th>
                    <th>ສາຂາ</th>
                    <th>ຈ/ນຊ/ມຂຶ້ນສອນແລ້ວ</th>
                    <th>ຈ/ນຊ/ມຍັງຕ້ອງຂຶ້ນສອນ</th>
                    <th style="text-align: center">ຊື່ ແລະ ນາມສະກຸນອາຈານ</th>
                    <th>ໝາຍເຫດ</th>

                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                    ?> 
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->orderBy('memos.MMID', 'desc')->get();
                    $active_hour = 0;
                    foreach($memos as $items){
                        $active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                    }
                    ?>
                    <?php if($active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->CREDIT); ?></td>
                        <td><?php echo e($item->classroomtypename); ?></td>
                        <td style="text-align: center"><?php echo e($item->YLEVEL); ?></td>
                        <td><?php echo e($item->Group); ?></td>
                        <td><?php echo e($item->COURSENAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?>/<?php echo e(number_format($item->NUMBER_HOUR)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($item->NUMBER_HOUR - $active_hour)); ?></td>
                        <td ><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></td>
                        <td >ສອນບໍ່ເຕັມ</td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <div class="text-right" style="padding:10px;margin-right:2.4cm;font-size:14pt;">
                     <p><b>ພາກວິຊາ</b></p>
                </div>
              </div>
                <?php $__env->startPush('scripts'); ?>
                    <script>
                        //print sale
                                  $('#btn-print').click(function() {
                                        var printContents = $(".print-content").html();
                                        var originalContents = document.body.innerHTML;
                                        document.body.innerHTML = printContents;
                                        window.print();
                                        document.body.innerHTML = originalContents;
                                        location.reload();
                                });
                                $('#ExportToExcel').click(function(){
                                      let file = new Blob([$('#page-content').html()], { type: "application/vnd.ms-excel" });
                                      let url = URL.createObjectURL(file);
                                      let a = $("<a />", {
                                          href: url,
                                          download: "filename.xls"
                                      }).appendTo("div").get(0).click();
                                      e.preventDefault();
                                 });
                                 $(document).ready( function(){
                                      $('#selectcourse').select2();
                                      $('#selectcourse').on('change', function(e){
                                         window.livewire.find('<?php echo e($_instance->id); ?>').set('COURSEID', $('#selectcourse').select2("val"));
                                      });
                                 });
                  </script>
                <?php $__env->stopPush(); ?>  
                  <!-- end print content   -->
                  <!-- show details  -->
        <div wire:ignore.self class="modal fade" id="modal-show-detail">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
              <div class="text-center"><h5><b>ຂໍ້ມູນການຂຶ້ນຫ້ອງສອນຂອງອາຈານ <?php echo e($this->teacher); ?> ວິຊາ <?php echo e($this->subject); ?> (<?php echo e($this->classroomtype); ?>)</b></h5></div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ລໍາດັບ</th>
                                <th>ວັນ,ເດືອນ,ປີ ຂຶ້ນຫ້ອງ</th>
                                <th>ເວລາຂຶ້ນຫ້ອງ</th>
                                <th style="text-align: center">ເວລາລົງຫ້ອງ</th>
                                <th style="text-align: center">ສະຖານະ</th>
                                <th>ເຫດຜົນ</th>
                                <th>ຊື່ຄະນະຫ້ອງ</th>
                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                               $i = 1;
                              ?>
                              <?php $__currentLoopData = $this->memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                                    <td><?php echo e(date('H:i:s A', strtotime($item->DATETIME_IN))); ?></td>
                                    <td style="text-align: center"><?php echo e(date('H:i:s A', strtotime($item->DATETIME_OUT))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->status->NAME); ?></td>
                                    <td><?php echo e($item->SEASON_MORE); ?></td>
                                    <td><?php echo e($item->student->TITLE); ?> <?php echo e($item->student->FRTNAME); ?> <?php echo e($item->student->LSTNAME); ?></td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <div class="text-left font-weight-bold">
                                <p>-ຈໍານວນຊົ່ວໂມງສອນວິຊານີ້ = <?php echo e(number_format($this->all_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-success">-ຈໍານວນຊົ່ວໂມງທີ່ຂຶ້ນແລ້ວ = <?php echo e(number_format($this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-danger">-ຈໍານວນຊົ່ວໂມງສອນທີ່ຍັງຕ້ອງໄດ້ຂຶ້ນ = <?php echo e(number_format($this->all_hour - $this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                            </div>
                        </div>
              </div>
            </div>
          </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
      <!-- end -->
    </div>
</div>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/department/check-up-class-for-subject-component.blade.php ENDPATH**/ ?>