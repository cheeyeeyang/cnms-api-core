<div>
<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><u>ຕາຕະລາງສະຫຼຸບຊົ່ວໂມງສອນຂອງຈານ ພາກວິຊາ <?php if(!empty($this->DEPTID)): ?><?php echo e($this->department); ?><?php endif; ?> ປະຈໍາພາກຮຽນ <?php if($this->SEMESTER ==1): ?> I <?php else: ?> II <?php endif; ?> <?php if(!empty($this->acyear)): ?> ສົກຮຽນ <?php echo e($this->acyear); ?> <?php endif; ?></u></h5>
            </div>
            <div class="card-body">
              <div class="row">
                 <div class="col-md-2">
                    <input type="radio" value="1" wire:model="check_report">&nbsp;ສະຫຼຸບຕາມຄວາມຈິງ
                 </div>
                 <div class="col-md-2">
                    <input type="radio" value="0" wire:model="check_report">&nbsp;ສະຫຼຸບຕາມນະໂຍບາຍ
                 </div>
              </div>
            <div class="text-right">
                <a href="#" class="btn btn-success" id="ExportToExcel"><i class="fas fa-file"></i>&nbsp;Excel</a>
                <a href="#" class="btn btn-primary" id="btn-print"><i class="fas fa-print"></i>&nbsp;ປຣິ່ນ</a>
            </div>
              <div class="row">
              <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກພາກວິຊາ</label>
                             <select id="" wire:model="DEPTID" class="form-control <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <option value="">ເລືອກ</option>
                              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->DEPTID); ?>"><?php echo e($item->DEPTNAME); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກພາກຮຽນ</label>
                             <select class="form-control" wire:model="SEMESTER">
                                  <option value="1">ພາກຮຽນ I</option>
                                  <option value="2">ພາກຮຽນ II</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ສົກຮຽນ</label>
                             <select id="" wire:model="acyear" class="form-control <?php $__errorArgs = ['acyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->ACNAME); ?>"><?php echo e($item->ACNAME); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                          <label for=""> ເວລາເລີ່ມຕົ້ນ</label>
                          <input type="date" class="form-control" wire:model="start_date">
                        </div>
                     </div>
                     <div class="col-md-2">
                        <div class="form-group">
                          <label for=""> ເວລາສິ້ນສຸດ</label>
                          <input type="date" class="form-control" wire:model="end_date">
                        </div>
                     </div>
               </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <tbody>
                  <tr>
                          <td  rowspan="2"  style="vertical-align : middle;text-align:center;"><b>ລໍາດັບ</b></td>
                          <td rowspan="2"style="vertical-align : middle;text-align:left;"><b>ຊື່ ແລະ ນາມສະກຸນ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກປົກກະຕິ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກເສົາ-ທິດ</b></td>
                    </tr>
                    <tr style="text-align: center;font-weight:bold;">
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php 
                     $i = 1;
                     $total_practice_active_hour = 0;
                     $total_explain_active_hour = 0;
                     $total_try_active_hour = 0;
                     $weekend_total_practice_active_hour = 0;
                     $weekend_total_explain_active_hour = 0;
                     $weekend_total_try_active_hour = 0;
                    ?>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($this->check_report == '1'){
                            if(!empty($this->SEMESTER) && !empty($this->acyear) && empty($this->start_date) && empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                              elseif(!empty($this->SEMESTER) && !empty($this->start_date) && !empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                            else{
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                    }else{
                            if(!empty($this->SEMESTER) && !empty($this->acyear) && empty($this->start_date) && empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                              elseif(!empty($this->SEMESTER) && !empty($this->start_date) && !empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                            else{
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                    }
                    ?>
                    <?php if($practice_active_hour > 0 || $explain_active_hour > 0 || $try_active_hour > 0 || $weekend_practice_active_hour > 0 || $weekend_explain_active_hour > 0 || $weekend_try_active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($try_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_try_active_hour)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr style="text-align: center;font-weight:bold">
                        <td colspan="2">ສະຫຼຸບ</td>
                        <td><u><?php echo e(number_format($total_practice_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($total_explain_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($total_try_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_practice_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_explain_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_try_active_hour)); ?></u></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
       <!-- print content -->
       <div class="print-content" style="display:none;" id="page-content">
                 <div class="text-center">
                   <p>ສາທາລະນະລັດ ປະຊາທິປະໄຕ ປະຊາຊົນລາວ</p>
                   <p>ສັນຕິພາບ ເອກະລາດ ປະຊາທິປະໄຕ ເອກະພາບ ວັດທະນະຖາວອນ</p>
                 </div>
                 <div class="text-center">
                       <b><h4>ຕາຕະລາງສະຫຼຸບຊົ່ວໂມງສອນຂອງຈານ ພາກວິຊາ <?php echo e($this->department); ?> ປະຈໍາພາກຮຽນ <?php if($this->SEMESTER ==1): ?> I <?php else: ?> II <?php endif; ?> <?php if(!empty($this->acyear_name)): ?>ສົກຮຽນ <?php echo e($this->acyear_name); ?> <?php endif; ?> <?php if(!empty($this->acyear)): ?> ສົກຮຽນ <?php echo e($this->acyear); ?> <?php endif; ?></h4></b>
                       <?php if(!empty($this->start_date) && !empty($this->end_date)): ?>
                         <br> <h4>ແຕ່ວັນທີ <?php echo e($this->start_date); ?> - <?php echo e($this->end_date); ?></h4>
                       <?php endif; ?>
                 </div>
                 <div class="header-content-Print">
                     <div class="left">
                     </div>
                     <div class="right">
                        <h6>ວັນທີ: <?php echo e($this->date_now); ?>

                     </div>
                 </div>
                <table class="report-print-content">
                  <tbody>
                  <tr>
                          <td  rowspan="2"  style="vertical-align : middle;text-align:center;"><b>ລໍາດັບ</b></td>
                          <td rowspan="2"style="vertical-align : middle;text-align:left;"><b>ຊື່ ແລະ ນາມສະກຸນ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກປົກກະຕິ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກເສົາ-ທິດ</b></td>
                    </tr>
                    <tr style="text-align: center;font-weight:bold;">
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php 
                     $i = 1;
                     $total_practice_active_hour = 0;
                     $total_explain_active_hour = 0;
                     $total_try_active_hour = 0;
                     $weekend_total_practice_active_hour = 0;
                     $weekend_total_explain_active_hour = 0;
                     $weekend_total_try_active_hour = 0;
                    ?>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if($this->check_report == '1'){
                            if(!empty($this->SEMESTER) && !empty($this->acyear) && empty($this->start_date) && empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                              elseif(!empty($this->SEMESTER) && !empty($this->start_date) && !empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                            else{
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                    }else{
                            if(!empty($this->SEMESTER) && !empty($this->acyear) && empty($this->start_date) && empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->SEMESTER)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                              elseif(!empty($this->SEMESTER) && !empty($this->start_date) && !empty($this->end_date)){
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->whereBetween('tt.created_at', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('tt.SEMESTER', $this->SEMESTER)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                            else{
                                  $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $practice_active_hour = 0;
                                  foreach($practice_hour as $items){
                                      $practice_active_hour += $items->HOUR;
                                  }
                                  $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $explain_active_hour = 0;
                                  foreach($explain_hour as $items){
                                      $explain_active_hour += $items->HOUR;
                                  }
                                  $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                                  $try_active_hour = 0;
                                  foreach($try_hour as $items){
                                      $try_active_hour += $items->HOUR;
                                  }

                                  $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_practice_active_hour = 0;
                                  foreach($weekend_practice_hour as $items){
                                      $weekend_practice_active_hour += $items->HOUR;
                                  }
                                  $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_explain_active_hour = 0;
                                  foreach($weekend_explain_hour as $items){
                                      $weekend_explain_active_hour += $items->HOUR;
                                  }
                                  $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                                  $weekend_try_active_hour = 0;
                                  foreach($weekend_try_hour as $items){
                                      $weekend_try_active_hour += $items->HOUR;
                                  }
                                  $total_practice_active_hour +=$practice_active_hour;
                                  $total_explain_active_hour +=$explain_active_hour;
                                  $total_try_active_hour +=$try_active_hour;
                                  $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                                  $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                                  $weekend_total_try_active_hour +=$weekend_try_active_hour;
                            }
                    }
                    ?>
                    <?php if($practice_active_hour > 0 || $explain_active_hour > 0 || $try_active_hour > 0 || $weekend_practice_active_hour > 0 || $weekend_explain_active_hour > 0 || $weekend_try_active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($try_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_try_active_hour)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr style="text-align: center;font-weight:bold">
                        <td colspan="2">ສະຫຼຸບ</td>
                        <td><u><?php echo e(number_format($total_practice_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($total_explain_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($total_try_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_practice_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_explain_active_hour)); ?></u></td>
                        <td><u><?php echo e(number_format($weekend_total_try_active_hour)); ?></u></td>
                    </tr>
                  </tbody>
                </table>
                <div class="text-right" style="padding:10px;margin-right:2.4cm;font-size:14pt;">
                     <p><b>ວິຊາການ</b></p>
                </div>
              </div>
                <?php $__env->startPush('scripts'); ?>
                    <script>
                        //print sale
                                  $('#btn-print').click(function() {
                                        var printContents = $(".print-content").html();
                                        var originalContents = document.body.innerHTML;
                                        document.body.innerHTML = printContents;
                                        window.print();
                                        document.body.innerHTML = originalContents;
                                        location.reload();
                                });
                                $('#ExportToExcel').click(function(){
                                      let file = new Blob([$('#page-content').html()], { type: "application/vnd.ms-excel" });
                                      let url = URL.createObjectURL(file);
                                      let a = $("<a />", {
                                          href: url,
                                          download: "filename.xls"
                                      }).appendTo("div").get(0).click();
                                      e.preventDefault();
                                 });
                  </script>
                <?php $__env->stopPush(); ?>  
                  <!-- end print content   -->
    </div>
</div>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/report-hour-of-teacher-component.blade.php ENDPATH**/ ?>