<!-- /.login-logo -->
<div class="card card-outline card-primary">
    <div class="card-body">
        <div class="text-center">
            <img src="<?php echo e(asset('frontend/img/logo.png')); ?>" height="100">
        </div>
      <form>
        <div class="form-group mb-3">
           <label for="">ຊື່ຜູ້ໃຊ້</label>
           <input type="text" class="form-control"  name="phone" placeholder="ຊື່ຜູ້ໃຊ້">
        </div>
        <div class="form-group mb-3">
          <label for="">ລະຫັດຜ່ານ</label>
          <input type="password" class="form-control"id="frm-login-pass"  name="password" placeholder="ລະຫັດຜ່ານ">
        </div>
        <div class="form-group mb-0">
            <div class="custom-control custom-checkbox">
                    <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                    <label class="custom-control-label" for="exampleCheck1">ສະແດງ</label>
            </div>
        </div>
        <div class="row">
          <div class="col-md-12 p-2">
              <button type="button" wire:click="Login" class="btn btn-primary btn-block"> <i class="fa fa-sign-in-alt"></i>&nbsp;ເຂົ້າລະບົບ</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card --><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/auth/login-teacher-component.blade.php ENDPATH**/ ?>