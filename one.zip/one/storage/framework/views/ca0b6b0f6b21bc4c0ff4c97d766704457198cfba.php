<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ເຂົ້າລະບົບ</title>
  <!-- Favicon -->
  <link rel="icon" href="<?php echo e(asset('frontend/img/logo.png')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <style>
    @import  url('https://fonts.googleapis.com/css2?family=Noto+Sans+Lao:wght@400&display=swap');
      *{
          font-family:'NoTo Sans Lao',sans-serif;
      }
  </style>
   <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="hold-transition login-page">
<div class="login-box">
  <?php echo e($slot); ?>

</div>
<!-- /.login-box -->
<!-- jQuery -->
<script src="<?php echo e(asset('admin/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin/dist/js/adminlte.min.js')); ?>"></script>
 <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/layouts/login.blade.php ENDPATH**/ ?>