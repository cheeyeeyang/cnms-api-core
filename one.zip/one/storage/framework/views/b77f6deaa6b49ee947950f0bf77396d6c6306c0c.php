<div>
    <h1>evaluation</h1>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/evaluation-component.blade.php ENDPATH**/ ?>