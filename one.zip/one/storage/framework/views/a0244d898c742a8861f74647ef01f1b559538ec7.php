<div>
<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
              <div class="card-body">
              <div class="card-header text-center">
                  <h5><u>ຈັດຕາຕະລາງສອນ<?php if(!empty($this->department)): ?>ຂອງພາກວິຊາ<?php echo e($this->department); ?>  <?php endif; ?></u></h5>
              </div>
              <form>
              <div class="row">
                    <div class="col-md-3">
                         <div class="form-group" wire:ignore>
                             <label for=""><span style="color:red;">*</span>ເລືອກພາກວິຊາ</label>
                             <select wire:model="DEPTID" class="form-control" id="selectdepartment">
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->DEPTID); ?>"><?php echo e($item->DEPTNAME); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </div>
                         <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for=""><span style="color:red;">*</span>ເລືອກສາຂາ</label>
                             <select wire:model="COURSEID" class="form-control" id="selectcourse">
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->COURSEID); ?>"><?php echo e($item->COURSENAME); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </div>
                         <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-3">
                                            <div class="form-group">
                                            <label><span style="color:red;">*</span> ປີທີ</label>
                                            <select id="" wire:model="YLEVEL" class="form-control <?php $__errorArgs = ['YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                            </select>
                                                <?php $__errorArgs = ['YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                    </div>
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for=""><span style="color:red;">*</span>ສອນຫ້ອງ</label>
                             <select wire:model="GRID" class="form-control">
                               <option value="">ເລືອກ</option>
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->Group); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                         </div>
                         <?php $__errorArgs = ['GRID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                      <div class="row">
                      <div class="col-md-3">
                                            <div class="form-group">
                                            <label><span style="color:red;">*</span>  ພາກຮຽນ</label>
                                            <select id="" wire:model="SEMESTER" class="form-control <?php $__errorArgs = ['SEMESTER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <option value="1">ພາກຮຽນທີ I</option>
                                                <option value="2">ພາກຮຽນທີ II</option>
                                            </select>
                                                <?php $__errorArgs = ['SEMESTER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                </div>
                                <div class="col-md-3">
                                <div class="form-group" wire:ignore>
                                    <label for=""><span style="color:red;">*</span>ສົກຮຽນ</label>
                                    <select wire:model="ACYEAR" class="form-control" id="selectacyear">
                                        <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->ACNAME); ?>"><?php echo e($item->ACNAME); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php $__errorArgs = ['ACYEAR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                       <div class="col-md-3">
                                <div class="form-group">
                                      <label for=""><span style="color:red;">*</span>ວິຊາ</label>
                                      <select wire:model="selectsubject" class="form-control">
                                      <option value="">ເລືອກ</option>
                                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <?php if(!empty($item->SUBJID)): ?>
                                            <option value="<?php echo e($item->SUBJID); ?>"><?php echo e($item->SUBJNAME); ?></option>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php $__errorArgs = ['selectsubject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3">
                              <div class="form-group">
                                  <label for=""><span style="color:red;">*</span>ຊົ່ວໂມງສອນແຕ່ລະຄັ້ງ</label>
                                  <input class="form-control" wire:model="HOUR" placeholder="2">
                                  <?php $__errorArgs = ['HOUR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                        </div>
                      </div>
                      <div class="row">
                       <div class="col-md-3">
                              <div class="form-group">
                                  <label for=""><span style="color:red;">*</span>ຈໍານວນຊົ່ວໂມງທັງໝົດ</label>
                                  <input class="form-control" wire:model="NUMBER_HOUR" placeholder="48">
                                  <?php $__errorArgs = ['NUMBER_HOUR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                        </div>
                        <div class="col-md-3">
                                <div class="form-group">
                                      <label for=""><span style="color:red;">*</span>ອາຈານ</label>
                                      <select wire:model="selectteacher" class="form-control" id="selectteacher">
                                      <option value="">ເລືອກ</option>
                                       <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->STID); ?>"><?php echo e($item->TITEL); ?><?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php $__errorArgs = ['selectteacher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3">
                                <div class="form-group" wire:ignore>
                                      <label for=""><span style="color:red;">*</span>ຫ້ອງຮຽນ</label>
                                      <select wire:model="selectclassroom" class="form-control" id="selectclassroom">
                                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->CRID); ?>"><?php echo e($item->NAME); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php $__errorArgs = ['selectclassroom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3">
                                <div class="form-group" wire:ignore>
                                      <label for=""><span style="color:red;">*</span>ເວລາສອນ</label>
                                      <select wire:model="time_id" class="form-control" id="selecttime">
                                        <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->TID); ?>"><?php echo e($item->DAY); ?> <?php echo e($item->TIME); ?> <?php echo e($item->REMARK); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                </div>
                                <?php $__errorArgs = ['time_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                  </div>
                  <div class="row">
                       <div class="col-md-12">
                           <a href="javascript:void(0)" wire:click="store" class="btn btn-primary w-100 mt-1"> <i class="fas fa-download"></i> ບັນທຶກ</a>
                       </div>
                  </div>
              </form>
              </div>
          </div>
          <div class="card">
            <div class="card-body">
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th style="text-align: center">ປະເພດ</th>
                    <th style="text-align: center">ປີ</th>
                    <th style="text-align: center">ພາກຮຽນ</th>
                    <th style="text-align: center">ຫ້ອງ</th>
                    <th>ອາຈານສອນ</th>
                    <th style="text-align: center">ຈັດການ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td>
                          <?php if(!empty($item->subject->SUBJNAME)): ?>
                               <?php echo e($item->subject->SUBJNAME); ?>

                          <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                         <?php if(!empty($item->subject->CREDIT)): ?>
                               <?php echo e($item->subject->CREDIT); ?>

                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($item->classroom->classroomtype->NAME): ?>
                               <?php echo e($item->classroom->classroomtype->NAME); ?>

                          <?php endif; ?>
                        </td>
                        <td style="text-align: center"><?php echo e($item->YLEVEL); ?></td>
                        <td style="text-align: center">
                         <?php if($item->SEMESTER ==1): ?>
                          ພາກຮຽນ I
                         <?php else: ?>
                          ພາກຮຽນ II
                         <?php endif; ?>
                        </td> 
                        <td style="text-align:center">
                          <?php if($item->group->Group): ?>
                               <?php echo e($item->group->Group); ?>

                          <?php endif; ?>
                        </td>
                        <td style="white-space:nowrap;"> 
                          <?php if($this->hiddenId == $item->TBID): ?>
                          <div class="form" >
                            <div class="form-group">
                                <select name="" wire:model="selectteacherteach" class="form-control" id="">
                                  <option selected class="text-success"><?php echo e($item->teacher->TITEL); ?> <?php echo e($item->teacher->FNAME); ?> <?php echo e($item->teacher->LNAME); ?></option>
                                  <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->STID); ?>"><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                            </div>
                            <?php if(!empty($this->selectteacherteach)): ?>
                                  <button wire:click="edit" type="button" class="btn btn-success btn-sm"><i class="fas fa-check"></i>ບັນທຶກ</button>
                           <?php endif; ?>
                          </div>
                          <?php else: ?>
                              <?php echo e($item->teacher->TITEL); ?> <?php echo e($item->teacher->FNAME); ?> <?php echo e($item->teacher->LNAME); ?>

                          <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                                  <input type="radio" wire:click="selectOne" wire:model="selectOne" value="<?php echo e($item->TBID); ?>"><i class="fas fa-pen"></i>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php $__env->startPush('scripts'); ?>
      <script>
          $(document).ready(function() {
            $('#selectsubject').select2();
            $('#selectsubject').on('change', function(e) {
              var data = $('#selectsubject').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('selectsubject',data);
            });
            $('#selectdepartment').select2();
            $('#selectdepartment').on('change', function(e) {
              var data = $('#selectdepartment').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('DEPTID',data);
            });
            $('#selectacyear').select2();
            $('#selectacyear').on('change', function(e) {
              var data = $('#selectacyear').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('ACYEAR',data);
            });
            $('#selecttime').select2();
            $('#selecttime').on('change', function(e) {
              var data = $('#selecttime').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('time_id',data);
            });
            $('#selectteacher').select2();
            $('#selectteacher').on('change', function(e) {
              var data = $('#selectteacher').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('selectteacher',data);
            });
            $('#selectclassroom').select2();
            $('#selectclassroom').on('change', function(e) {
              var data = $('#selectclassroom').select2("val");
              window.livewire.find('<?php echo e($_instance->id); ?>').set('selectclassroom',data);
            });
          });
      </script>
      <?php $__env->stopPush(); ?>
    </div>
</div>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/manage-class-table-component.blade.php ENDPATH**/ ?>