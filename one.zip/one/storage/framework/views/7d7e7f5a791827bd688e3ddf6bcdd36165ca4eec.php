<div>
<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
            <div class="card-header text-center">
               <h5><u>ກວດກາການຂຶ້ນຫ້ອງສອນຂອງອາຈານໃນພາກວິຊາ <?php if(!empty($this->department)): ?> <?php echo e($this->department); ?> <?php else: ?> <?php echo e(auth()->user()->staff->department->DEPTNAME); ?> <?php endif; ?></u></h5>
            </div>
            <div class="card-body">
              <div class="row">
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for="">ເລືອກພາກວິຊາ</label>
                             <select id="" wire:model="DEPTID" class="form-control <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->DEPTID); ?>"><?php echo e($item->DEPTNAME); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກພາກຮຽນ</label>
                             <select class="form-control" wire:model="semester">
                                  <option value="1">ພາກຮຽນ I</option>
                                  <option value="2">ພາກຮຽນ II</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for="">ສົກຮຽນ</label>
                             <select id="" wire:model="acyear" class="form-control <?php $__errorArgs = ['acyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->ACNAME); ?>"><?php echo e($item->ACNAME); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                         </div>
                    </div>
               </div>
              <div class="table-responsive mt-2">
              <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <tbody>
                  <tr>
                          <td  rowspan="2"  style="vertical-align : middle;text-align:center;"><b>ລໍາດັບ</b></td>
                          <td rowspan="2"style="vertical-align : middle;text-align:left;"><b>ຊື່ ແລະ ນາມສະກຸນ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກປົກກະຕິ</b></td>
                          <td colspan="<?php echo e($classroomtypes->count()); ?>" style="text-align: center"><b>ສອນພາກເສົາ-ທິດ</b></td>
                          <td rowspan="2"style="vertical-align : middle;text-align:center;"><b>ລາຍລະອຽດ</b></td>
                    </tr>
                    <tr style="text-align: center;font-weight:bold;">
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item->NAME); ?></td>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php
                    $i = 1;
                     $total_practice_active_hour = 0;
                     $total_explain_active_hour = 0;
                     $total_try_active_hour = 0;
                     $weekend_total_practice_active_hour = 0;
                     $weekend_total_explain_active_hour = 0;
                     $weekend_total_try_active_hour = 0;
                    ?>
                    <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        if(!empty($this->semester) && !empty($this->acyear)){
                        $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $practice_active_hour = 0;
                        foreach($practice_hour as $items){
                            $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $explain_active_hour = 0;
                        foreach($explain_hour as $items){
                            $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $try_active_hour = 0;
                        foreach($try_hour as $items){
                            $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }

                        $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 1)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_practice_active_hour = 0;
                        foreach($weekend_practice_hour as $items){
                            $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 2)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_explain_active_hour = 0;
                        foreach($weekend_explain_hour as $items){
                            $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('tt.SEMESTER', $this->semester)->where('tt.ACYEAR', $this->acyear)->where('crt.CRTID', 3)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_try_active_hour = 0;
                        foreach($weekend_try_hour as $items){
                            $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $total_practice_active_hour +=$practice_active_hour;
                        $total_explain_active_hour +=$explain_active_hour;
                        $total_try_active_hour +=$try_active_hour;
                        $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                        $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                        $weekend_total_try_active_hour +=$weekend_try_active_hour;
                      }else{
                        $practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $practice_active_hour = 0;
                        foreach($practice_hour as $items){
                            $practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $explain_active_hour = 0;
                        foreach($explain_hour as $items){
                            $explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->where('mm.STTID', 1)->where('t.REMARK', 'ປົກກະຕິ')->orderBy('mm.MMID', 'desc')->get();
                        $try_active_hour = 0;
                        foreach($try_hour as $items){
                            $try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }

                        $weekend_practice_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 1)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_practice_active_hour = 0;
                        foreach($weekend_practice_hour as $items){
                            $weekend_practice_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $weekend_explain_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 2)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_explain_active_hour = 0;
                        foreach($weekend_explain_hour as $items){
                            $weekend_explain_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->join('times as t','t.TID','=','tt.TID')->where('sf.STID', $item->STID)->where('crt.CRTID', 3)->where('mm.STTID', 1)->where('t.REMARK', 'ເສົາ-ທິດ')->orderBy('mm.MMID', 'desc')->get();
                        $weekend_try_active_hour = 0;
                        foreach($weekend_try_hour as $items){
                            $weekend_try_active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                        }
                        $total_practice_active_hour +=$practice_active_hour;
                        $total_explain_active_hour +=$explain_active_hour;
                        $total_try_active_hour +=$try_active_hour;
                        $weekend_total_practice_active_hour +=$weekend_practice_active_hour;
                        $weekend_total_explain_active_hour +=$weekend_explain_active_hour;
                        $weekend_total_try_active_hour +=$weekend_try_active_hour;
                      }
                    ?>
                    <?php if($practice_active_hour > 0 || $explain_active_hour > 0 || $try_active_hour > 0 || $weekend_practice_active_hour > 0 || $weekend_explain_active_hour > 0 || $weekend_try_active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->TITEL); ?> <?php echo e($item->FNAME); ?> <?php echo e($item->LNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($try_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_practice_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_explain_active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($weekend_try_active_hour)); ?></td>
                        <td style="text-align: center"><a href="<?php echo e(route('admin.detailcheckteacherupclass', ['slug' => $item->STID])); ?>"><u>ລາຍລະອຽດ</u></a></td>
                    </tr>
                    <?php endif; ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div class="d-flex justify-space-between">
                   <?php echo e($memos->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/check-teacher-up-class-component.blade.php ENDPATH**/ ?>