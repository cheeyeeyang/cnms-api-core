<div>
<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><u>ຈັດຕາຕະລາງສອນຂອງພາກວິຊາ ຄອມພິວເຕີ</u></h5>
            </div>
            <div class="card-body">
              <div class="row">
                    <div class="col-md-3">
                         <div class="form-group">
                             <label for="">ເລືອກສາຂາ</label>
                             <select class="form-control">
                                  <option value="">ພັດທະນາເວັບໄຊ</option>
                                  <option value="">ພັດທະນາໂປຣແກຣມ</option>
                                  <option value="">ວິທະຍາສາດຄອມພິວເຕີ</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກຫ້ອງ</label>
                             <select class="form-control">
                                  <option value="">4CW1</option>
                                  <option value="">4CW2</option>
                                  <option value="">2CPR1</option>
                                  <option value="">2CPR2</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກປີ</label>
                             <select class="form-control">
                                  <option value="">2018-2019</option>
                                  <option value="">2019-2020</option>
                                  <option value="">2021-202022</option>
                             </select>
                         </div>
                    </div>
                    <div class="col-md-2">
                         <div class="form-group">
                             <label for="">ເລືອກພາກຮຽນ</label>
                             <select class="form-control">
                                  <option value="">ພາກຮຽນ I</option>
                                  <option value="">ພາກຮຽນ II</option>
                             </select>
                         </div>
                    </div>
               </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th>ໜ່ວຍກິດ</th>
                    <th style="text-align: center">ປະເພດ</th>
                    <th style="text-align: center">ປີ</th>
                    <th>ພາກຮຽນ</th>
                    <th>ເລືອກອາຈານ</th>
                    <th style="text-align: center">ຈັດການ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <tr>
                        <td style="text-align: center">1</td>
                        <td>ຖານຂໍ້ມູນ</td>
                        <td>3(2-2-5)</td>
                        <td>ບັນຍາຍ</td>
                        <td style="text-align: center">1</td>
                        <td style="text-align: center">I</td>
                        <td><select name="" class="form-control" id="">
                           <option value="">ປທ.ສຸລິດ ແສງມະໂນທໍາ</option>
                           <option value="">ປທ.ສຸລິດ ແສງມະໂນທໍາ</option>
                        </select></td>
                        <td style="text-align: center"><a href="#" class="btn btn-success" wire:click="Save">ບັນທຶກ</a></td>
                    </tr>
                    <tr>
                        <td style="text-align: center">1</td>
                        <td class="text-success">ລາວສຶກສາ</td>
                        <td>3(2-2-5)</td>
                        <td>ບັນຍາຍ</td>
                        <td style="text-align: center">1</td>
                        <td style="text-align: center">I</td>
                        <td><select name="" class="form-control" id="">
                           <option value="">ປທ.ສຸລິດ ແສງມະໂນທໍາ</option>
                           <option value="">ປທ.ສຸລິດ ແສງມະໂນທໍາ</option>
                        </select></td>
                        <td style="text-align: center"><a href="#" class="btn btn-success" wire:click="Save">ບັນທຶກ</a></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
</div>
<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/department/dashboard-component.blade.php ENDPATH**/ ?>