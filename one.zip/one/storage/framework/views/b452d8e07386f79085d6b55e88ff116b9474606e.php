<div>
    <div>
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">ຂໍ້ມູນແຜນນັດພົບລູກຄ້ານອກແຜນ</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                            <li class="breadcrumb-item active">ນັດໝາຍນອກແຜນ</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <!--customers -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('admin.detailappointment')); ?>" class="btn btn-primary"><i
                                            class="fa fa-plus-circle"></i> ເພີ່ມແຜນນັດໝາຍ</a>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3 mt-2">
                                    <div class="form-group">
                                        <label for="">ຄົ້ນຫາ</label>
                                        <input type="text" class="form-control" wire:model="search"
                                            placeholder="ຊື່ ຫຼື ເບີໂທ">
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                    <thead class="bg-info">
                                        <tr>
                                            <th>ປຸ່ມຄໍາສັ່ງ</th>
                                            <th style="text-align: center">ລ/ດ</th>
                                            <th>ຊື່  ແລະ ນາມສະກຸນ</th>
                                            <th>ເບີໂທ</th>
                                            <th>ບ້ານ</th>
                                            <th style="text-align: center">ເມືອງ</th>
                                            <th style="text-align: center">ແຂວງ</th>
                                            <th style="text-align: center">ພະນັກງານ</th>
                                            <th style="text-align: center">ເນື້ອໃນສົນທະນາ</th>
                                            <th style="text-align: center">ວັນທີ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><a href="#" class="btn btn-success btn-sm" wire:click="showDetail('<?php echo e($item->ID); ?>')">ລາຍລະອຽດ</a></td>
                                            <td style="text-align: center">
                                                <?php echo e($i++); ?></td>
                                            <td>
                                                <?php echo e($item->CLIENTNAME); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->CLIENTPHONE); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->CLIENTVILLAGE); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->CLIENTDISTRICT); ?>

                                            </td>
                                            <td>
                                                <?php echo e($item->CLIENTPROVINCE); ?>

                                            </td>
                                            <td>
                                                <?php if(!empty($item->employee->TITLE)): ?>
                                                <?php echo e($item->employee->TITLE); ?>

                                                <?php endif; ?>
                                                <?php if(!empty($item->employee->FNAME)): ?>
                                                <?php echo e($item->employee->FNAME); ?>

                                                <?php endif; ?>
                                                <?php if(!empty($item->employee->LNAME)): ?>
                                                <?php echo e($item->employee->LNAME); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($item->DISRIPTION); ?></td>
                                            <td><?php echo e(date('d/m/Y H:i:s', strtotime($item->DATETIME))); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row justify-content-center">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- /.modal-location -->
            <div wire:ignore.self class="modal fade" id="modal-location">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title text-primary"><i class="fa fa-calendar-check" aria-hidden="true"></i><u> ແຜນນັດໝາຍ</u></h3>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p class="text-center text-danger">
                                <i class="fa fa-clock"></i> ວັນທີນັດໝາຍ: <?php echo e(date('d/m/Y H:i:s', strtotime($this->date))); ?>

                            </p>
                            <p>ພະນັກງານ: <?php echo e($this->emp_fullname); ?></p>
                            <p>ລູກຄ້າ: <?php echo e($this->client_fullname); ?></p>
                            <div class="row">
                            <div class="col-md-12">
                                    <div class="bg-light p-30 mb-30">
                                        <div class="text-center p-2">
                                            <iframe
                                                src="https://maps.google.com/maps?q=<?php echo e($this->lat); ?>,<?php echo e($this->long); ?>&hl=es;z=13&output=embed"
                                                style="width:100%;height:300px;"></iframe>
                                        </div>
                                        <p class="text-danger">ຈຸດນັດພົບລູກຄ້າ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
        //show location
        window.addEventListener('show-modal-location', event => {
            $('#modal-location').modal('show');
        })
        window.addEventListener('hide-modal-location', event => {
            $('#modal-location').modal('hide');
        })
        </script>
        <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/appointmentoffplan/appointmentoffplan.blade.php ENDPATH**/ ?>