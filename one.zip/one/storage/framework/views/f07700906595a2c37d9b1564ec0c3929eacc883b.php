<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-primary card-outline">
            <div class="card-header text-center">
               <h5><b>ລາຍຊື່ນັກສຶກສາຂາດຂອງຫ້ອງ 1cw1</b></h5>
            </div>
            <div class="card-body">
            <div class="row">
                   <div class="col-md-2 p-1">
                        <div class="form-group">
                             <label for="">ເລືອກຫ້ອງ</label>
                             <select name="" wire:model="group" id="" class="form-control">
                                 <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->Group); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                        </div>
                   </div>
                </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th style="text-align: center">ລະຫັດນັກສຶກສາ</th>
                    <th style="text-align: center">ເພດ</th>
                    <th style="text-align: center">ຊື່</th>
                    <th>ນາມສະກຸນ</th>
                    <th>ເບີໂທ</th>
                    <th style="text-align: center">ຫ້ອງ</th>
                    <th style="text-align: center">ຂາດ</th>
                    <th style="text-align: center">ອະນຸຍາດ</th>
                    <th>ເຫດຜົນ</th>
                    <th style="text-align: center">ວັນທີ</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $count_absent = DB::table('studentabsents')->where('TBID', $item->TBID)->where('STDID', $item->STDID)->WhereNull('REMARK')->get();
                        
                    ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                        <td style="text-align: center">
                        <?php if(!empty($item->TITLE)): ?>
                            <?php echo e($item->TITLE); ?>

                        <?php endif; ?>
                        </td>
                        <td>
                        <?php if(!empty($item->FRTNAME)): ?>
                           <?php echo e($item->FRTNAME); ?>

                         <?php endif; ?>
                        </td>
                        <td>
                        <?php if(!empty($item->LSTNAME)): ?>
                           <?php echo e($item->LSTNAME); ?>

                        <?php endif; ?>
                        </td>
                        <td>
                        <?php if(!empty($item->PHONE)): ?>
                           <?php echo e($item->PHONE); ?>

                        <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                        <?php if(!empty($item->Group)): ?>
                           <?php echo e($item->Group); ?>

                        <?php endif; ?>
                        </td>
                        <td style="text-align: center"><?php echo e($count_absent->count()); ?></td>
                        <td>555</td>
                        <td style="text-align: center">
                              <?php echo e($item->REMARK); ?>

                        </td>
                        <td style="text-align: center"><?php echo e(date('d-m-Y H:i:s A', strtotime($item->created_at))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div>
                <?php echo e($data->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/teacher/student-absent-component.blade.php ENDPATH**/ ?>