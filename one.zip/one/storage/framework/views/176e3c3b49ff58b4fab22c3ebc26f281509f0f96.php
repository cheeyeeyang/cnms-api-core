<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">

                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                        <li class="breadcrumb-item active"><a
                                href="<?php echo e(route('admin.appointment')); ?>">ຈັດການຂໍ້ມູນແຜນນັດໝາຍ</li></a>
                        <li class="breadcrumb-item active"><a
                                href="<?php echo e(route('admin.detailappointment')); ?>">ລູກຄ້າທີ່ບໍ່ມັກຊື້ສິນຄ້າ</li></a>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!--customers -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="card-header text-primary">
                            <h5><i class="fas fa-user"></i> <?php echo e($this->fullname); ?></h5>
                        </div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                <thead class="bg-info">
                                    <tr>
                                        <th style="text-align: center">ລ/ດ</th>
                                        <th>ລະຫັດສິນຄ້າ</th>
                                        <th>ຊື່ສິນຄ້າ</th>
                                        <th>ເສັ້ນສະແດງ</th>
                                        <th style="text-align: center">ລາຍລະອຽດ</th>
                                        <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    use Carbon\Carbon;
                                    $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                    $show_chart = 'chart'.$i;
                                    $chartData = DB::table('bill_details as bd')->join('bills as b', 'bd.bill_number',
                                    '=', 'b.bill_number')->select(DB::raw("SUM(b.total_amount) as sum"),
                                    DB::raw("Month(b.bill_date) as month"))
                                    ->where('bd.product_id',$item->product_id)
                                    ->where( 'b.bill_date', '>=', Carbon::now()->subMonths(6))
                                    ->groupBy(DB::raw("Month(b.bill_date)"))
                                    ->orderBy('month', 'ASC')
                                    ->pluck('sum');
                                    $c_Data = DB::table('bill_details as bd')->join('bills as b', 'bd.bill_number',
                                    '=', 'b.bill_number')->select(DB::raw("Month(b.bill_date) as month"))
                                    ->where('bd.product_id',$item->product_id)
                                    ->where( 'b.bill_date', '>=', Carbon::now()->subMonths(6))
                                    ->groupBy(DB::raw("Month(b.bill_date)"))
                                    ->orderBy('month', 'ASC')
                                    ->get();
                                    foreach($c_Data as $c_item){
                                    if($c_item->month ==1){
                                    $categoryData[] = ['01'];
                                    }elseif($c_item->month ==2){
                                    $categoryData[] = ['02'];
                                    }
                                    elseif($c_item->month ==3){
                                    $categoryData[] = ['03'];
                                    }
                                    elseif($c_item->month ==4){
                                    $categoryData[] = ['04'];
                                    }
                                    elseif($c_item->month ==5){
                                    $categoryData[] = ['05'];
                                    }
                                    elseif($c_item->month ==6){
                                    $categoryData[] = ['06'];
                                    }
                                    elseif($c_item->month ==7){
                                    $categoryData[] = ['07'];
                                    }
                                    elseif($c_item->month ==8){
                                    $categoryData[] = ['08'];
                                    }
                                    elseif($c_item->month ==9){
                                    $categoryData[] = ['09'];
                                    }else{
                                    $categoryData[] = [$c_item->month];
                                    }
                                    }
                                    ?>
                                    <tr>
                                        <td style="vertical-align : middle;text-align:center;"><?php echo e($i++); ?></td>
                                        <td style="vertical-align : middle;text-align:center;">
                                            <?php echo e($item->product_id); ?>

                                        </td>
                                        <td style="vertical-align : middle;">
                                            <?php echo e($item->product_name); ?>

                                        </td>
                                        <td>
                                            <?php if($chartData->count() > 0): ?>
                                            <center>
                                                <div id=<?php echo e($show_chart); ?> wire:ignore style="width: 500px;height:200px;"
                                                    wire:click="showSale(<?php echo e($item->product_id); ?>)"></div>
                                            </center>
                                            <!-- //chart -->
                                            <script src="https://code.highcharts.com/highcharts.js"></script>

                                            <script type="text/javascript">
                                            var chartData = <?php echo json_encode($chartData)?>;
                                            var chart = <?php echo json_encode($show_chart)?>;
                                            var categoriesData = <?php echo json_encode($categoryData)?>;
                                            Highcharts.chart(chart, {
                                                xAxis: {
                                                    categories: categoriesData
                                                },
                                                legend: {
                                                    layout: 'vertical',
                                                    align: 'right',
                                                    verticalAlign: 'middle'
                                                },
                                                plotOptions: {
                                                    series: {
                                                        allowPointSelect: true
                                                    }
                                                },
                                                series: [{
                                                    // name: 'New Users',
                                                    data: chartData
                                                }],
                                                responsive: {
                                                    rules: [{
                                                        condition: {
                                                            maxWidth: 100
                                                        },
                                                        chartOptions: {
                                                            legend: {
                                                                layout: 'horizontal',
                                                                align: 'center',
                                                                verticalAlign: 'bottom'
                                                            }
                                                        }
                                                    }]
                                                }
                                            });
                                            </script>
                                            <?php else: ?>
                                            <p class="text-danger text-center">
                                                ຍັງບໍ່ມີຂໍ້ມູນ
                                            </p>
                                            <?php endif; ?>
                                        </td>
                                        <td style="vertical-align : middle;text-align:center;">
                                            <?php echo e($item->product_generic); ?></td>
                                        <td style="vertical-align : middle;text-align:center;">
                                            <a href="#" wire:click="showDetail('<?php echo e($item->product_id); ?>')"
                                                class="btn btn-success btn-sm"><i class="fa fa-plus"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row justify-content-center">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- //add plan -->
    <div wire:ignore.self class="modal fade" id="modal-detail">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title text-primary"><i class="fa fa-plus"></i> ເພີ່ມແຜນນັດໝາຍ </h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for=""><span style="color:red;">*</span>ຄໍາຖາມ</label>
                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex flex-row">
                                        <input type="checkbox" value="<?php echo e($item->QUESTIONID); ?>"
                                            wire:model="question" />&nbsp;<h5>
                                            <?php echo e($item->QUESTION); ?></h5>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">ຄໍາຖາມອື່ນໆ</label>
                                    <textarea wire:model="admin_question" placeholder="ຄໍາຖາມອື່ນໆ ..." rows="3"
                                        cols="50" class="form-control">
                                    </textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label for=""><span style="color:red;">*</span>ພະນັກງານ</label>
                                    <select class="form-control" wire:model="emp_id">
                                        <option value="">ເລືອກ</option>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->EMPID); ?>"><?php echo e($item->TITLE); ?> <?php echo e($item->FNAME); ?>

                                            <?php echo e($item->LNAME); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['emp_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label for=""><span style="color:red;">*</span> ວັນທີນັດໝາຍ</label>
                                    <input type="datetime-local" class="form-control" placeholder="ນາມສະກຸນ"
                                        wire:model="date">
                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""><span style="color:red;">*</span> Lat</label>
                                    <input type="text" class="form-control" placeholder="Lat"
                                        wire:model="lat">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for=""><span style="color:red;">*</span> Long</label>
                                    <input type="text" class="form-control" placeholder="Long"
                                        wire:model="long">
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-success btn-block" wire:click="SavePlan"><i
                                class="fas fa-plus"></i>&nbsp;ບັນທຶກ</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- //show bill detail back 3 months -->
    <div wire:ignore.self class="modal fade" id="modal-bill-back">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary"> <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        ລາຍການຂາຍ 3ເດືອນຢ້ອນຫຼັງ <?php if(count($this->billback) >
                        0): ?>(<?php echo e(number_format(count($this->billback))); ?> ລາຍການ) <?php endif; ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php if(count($this->billback) > 0): ?>

                    <div class="row">
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                <thead class="bg-success">
                                    <tr>
                                        <th style="text-align: center">ລ/ດ</th>
                                        <th style="text-align: center">ລະຫັດບິນ</th>
                                        <th>ຊື່ສິນຄ້າ</th>
                                        <th style="text-align: center">ຈໍານວນ</th>
                                        <th style="text-align: center">ລາຄາ</th>
                                        <th style="text-align: center">ລວມ</th>
                                        <th style="text-align: center">ວັນທີຊື້</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $this->billback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($i++); ?></td>
                                        <td style="text-align: center">
                                            <?php if(!empty($item->bill_number)): ?>
                                            <?php echo e($item->bill_number); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(!empty($this->product_id)): ?>
                                            <?php echo e($this->product_id); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: center"><?php if(!empty($item->quantity)): ?><?php echo e($item->quantity); ?>

                                            <?php endif; ?></td>
                                        <td style="text-align: center"><?php if(!empty($item->product_saleprice)): ?>
                                            <?php echo e(number_format($item->product_saleprice)); ?> <?php endif; ?></td>
                                        <td style="text-align: center">
                                            <?php if(!empty($item->product_saleprice) || !empty($item->quantity)): ?>
                                            <?php echo e(number_format($item->quantity * $item->product_saleprice)); ?></td>
                                        <?php endif; ?>
                                        <td style="text-align: center"><?php if(!empty($item->bill_date)): ?>
                                            <?php echo e(date('d/m/Y', strtotime($item->bill_date))); ?> <?php endif; ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="text-center">
                        <h4 class="text-danger">ຂໍອະໄພ ຍັງບໍ່ມີຂໍ້ມູນ</h4>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
    //show add plan
    window.addEventListener('show-modal-detail', event => {
        $('#modal-detail').modal('show');
    })
    window.addEventListener('hide-modal-detail', event => {
        $('#modal-detail').modal('hide');
    })
    //show 
    window.addEventListener('show-modal-bill-back', event => {
        $('#modal-bill-back').modal('show');
    })
    window.addEventListener('hide-modal-bill-back', event => {
        $('#modal-bill-back').modal('hide');
    })
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/setting/detail-add-appointment-component.blade.php ENDPATH**/ ?>