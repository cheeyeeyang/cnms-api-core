<div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
           <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('student.subject')); ?>">ໜ້າຫຼັກ</a></li>
                <li class="breadcrumb-item active">ຂໍ້ມູນສ່ວນຕົວ</li>
            </ol>
        </div>
      </div>
    </div>
  </div>
<section class="content">
      <div class="container-fluid">
        <div class="row p-4 justify-content-center">
                <div class="col-md-4">
                    <!-- Profile Image -->
                    <div class="card card-primary card-outline">
                    <div class="card-body box-profile">
                        <div class="text-center">
                        <img class="profile-user-img img-fluid img-circle"
                            src="<?php echo e(asset('frontend/img/user.png')); ?>"
                            alt="User profile picture">
                        </div>
                        <h3 class="profile-username text-center"><?php echo e(auth()->guard('webstudent')->user()->student->TITLE); ?> <?php echo e(auth()->guard('webstudent')->user()->student->FRTNAME); ?> <?php echo e(auth()->guard('webstudent')->user()->student->LSTNAME); ?></h3>
                        <p class="text-muted text-center">ລະຫັດນັກສຶກສາ: <?php echo e(auth()->guard('webstudent')->user()->STDUSER); ?></p>
                    </div>
                    <form>
                        <div class="row ml-4 mr-4 mb-4">
                          <?php if(Session::has('not_match')): ?>
                          <div class="col-md-12 p-2">
                              <buttun class="btn btn-danger w-100"><?php echo e(Session::get('not_match')); ?></buttun>
                          </div>
                          <?php endif; ?>
                            <!-- <div class="col-md-12">
                                <div class="form-group">
                                     <label for="">ຊື່ຜູ້ໃຊ້</label>
                                      <input type="text" class="form-control" placeholder="ຊື່ຜູ້ໃຊ້" wire:model="username">
                                      <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div> -->
                            <div class="col-md-12">
                                <div class="form-group">
                                     <label for="">ລະຫັດຜ່ານ</label>
                                      <input type="password" class="form-control" placeholder="ລະຫັດຜ່ານ" wire:model="password">
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                     <label for="">ຢືນຢັນລະຜ່ານ</label>
                                      <input type="password" class="form-control" placeholder="ຢືນຢັນລະຜ່ານ" wire:model="confirm_password">
                                      <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <a wire:click="edit" class="btn btn-success btn-sm w-100"><i class="fas fa-pen"></i>&nbsp;ແກ້ໄຂ</a>
                            </div>
                        </div>
                    </form>
                    <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/student/student-edit-component.blade.php ENDPATH**/ ?>