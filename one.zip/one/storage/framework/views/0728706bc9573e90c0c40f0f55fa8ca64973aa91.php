<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CNMS</title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('frontend/img/logo.png')); ?>" />
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.min.css')); ?>">
    <!-- Toastr -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/toastr/toastr.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">
    <!-- flag-icon-css -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
    <link href="<?php echo e(asset('css/sidebars.css')); ?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome-free/css/all.min.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.min.css')); ?>">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/OverlayScrollbars.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/adminlte.min.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/buttons.bootstrap4.min.css')); ?>">
    <style>
    @import  url('https://fonts.googleapis.com/css2?family=Noto+Sans+Lao:wght@400&display=swap');

    * {
        font-family: 'NoTo Sans Lao', sans-serif;
    }
    </style>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
            <div class="container-fluid">
                <!-- <a href="<?php echo e(route('admin.dashboard')); ?>" class="navbar-brand">
      <img src="<?php echo e(asset('frontend/img/logo.png')); ?>" alt="AdminLTE Logo" class="brand-image"> -->
                <!-- <span class="brand-text font-weight-light">ຄວທ</span> -->
                <!-- </a> -->
                <!-- Left navbar links -->
                <div class="collapse navbar-collapse order-3" id="navbarCollapse">
                    <ul class="navbar-nav">
                        <!--Modules-->
                        <li class="nav-item dropdown">
                            <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false" class="nav-link dropdown-toggle">ຈັດການຂໍ້ມູນ</a>
                            <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
                                <li><a href="<?php echo e(route('admin.employee')); ?>" class="dropdown-item"><i
                                            class="fa fa-caret-right" style="font-size:12pt;"
                                            aria-hidden="true"></i>&nbsp;ຈັດການຂໍ້ມູນພະນັກງານ</a></li>
                                <li><a href="<?php echo e(route('admin.question')); ?>" class="dropdown-item"><i
                                            class="fa fa-caret-right" style="font-size:12pt;"
                                            aria-hidden="true"></i>&nbsp;ຈັດການຂໍ້ມູນຄໍາຖາມ</a></li>
                                <li><a href="<?php echo e(route('admin.promotion')); ?>" class="dropdown-item"><i
                                            class="fa fa-caret-right" style="font-size:12pt;"
                                            aria-hidden="true"></i>&nbsp;ຈັດການຂໍ້ມູນໂປຣໂມຊັ່ນ</a></li>
                                <li class="dropdown-submenu dropdown-hover">
                                    <a id="dropdownSubMenu2" href="#" role="button" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false"
                                        class="dropdown-item dropdown-toggle"><i class="fa fa-caret-right"
                                            style="font-size:12pt;" aria-hidden="true"></i>&nbsp;ຈັດການແຜນນັດພົບ</a>
                                    <ul aria-labelledby="dropdownSubMenu2" class="dropdown-menu border-0 shadow">
                                        <li><a href="<?php echo e(route('admin.appointment')); ?>" class="dropdown-item"><i
                                                    class="fa fa-caret-right" style="font-size:12pt;"
                                                    aria-hidden="true"></i>&nbsp;ຈັດການແຜນນັດພົບໃນແຜນ</a></li>
                                        <li><a href="<?php echo e(route('admin.appointmentoffplan')); ?>" class="dropdown-item"><i
                                                    class="fa fa-caret-right" style="font-size:12pt;"
                                                    aria-hidden="true"></i>&nbsp;ຈັດການແຜນນັດພົບຍອກແຜນ</a></li>
                                    </ul>
                                </li> <!-- end li 1 -->
                                <li class="dropdown-submenu dropdown-hover">
                                    <a id="dropdownSubMenu2" href="#" role="button" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false"
                                        class="dropdown-item dropdown-toggle"><i class="fa fa-caret-right"
                                            style="font-size:12pt;" aria-hidden="true"></i>&nbsp;ຕັ້ງຄ່າລະບົບ</a>
                                    <ul aria-labelledby="dropdownSubMenu2" class="dropdown-menu border-0 shadow">
                                        <li><a href="<?php echo e(route('admin.role')); ?>" class="dropdown-item"><i
                                                    class="fa fa-caret-right" style="font-size:12pt;"
                                                    aria-hidden="true"></i>&nbsp;ຈັດການຂໍ້ມູນສິດນໍາໃຊ້</a></li>
                                        <li><a href="<?php echo e(route('admin.user')); ?>" class="dropdown-item"><i
                                                    class="fa fa-caret-right" style="font-size:12pt;"
                                                    aria-hidden="true"></i>&nbsp;ຈັດການຂໍ້ມູນຜູ້ໃຊ້ລະບົບ</a></li>
                                    </ul>
                                </li> <!-- end li 1 -->
                            </ul>
                        </li> <!-- end li 1 -->
                        <li class="nav-item dropdown">
                            <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false" class="nav-link dropdown-toggle">ລາຍງານ</a>
                            <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
                                <li><a href="" class="dropdown-item"><i class="fa fa-caret-right"
                                            style="font-size:12pt;"
                                            aria-hidden="true"></i>&nbsp;ລາຍງານແຜນນັດໝາຍໃນແຜນ</a></li>
                                <li><a href="" class="dropdown-item"><i class="fa fa-caret-right"
                                            style="font-size:12pt;"
                                            aria-hidden="true"></i>&nbsp;ລາຍງານແຜນນັດໝາຍໃນແຜນ</a></li>
                            </ul>
                        </li> <!-- end li 1 -->
                    </ul>
                </div>
                <!-- Right navbar links -->
                <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
                    <!-- Notifications Dropdown Menu -->
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="far fa-bell"></i>
                            <span class="badge badge-warning navbar-badge"><?php echo e($no_appointment->count()); ?></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <span class="dropdown-header bg-info"><i class="fa fa-bell"> </i>
                                <?php echo e($no_appointment->count()); ?></span>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('admin.appointment')); ?>" class="dropdown-item">
                                <i class="fas fa-users text-info"></i> ແຈ້ງເຕືອນພົບລູກຄ້າ
                                <br>
                                <span class="float-right text-muted text-sm">
                                    555</span>
                            </a>
                        </div>
                    </li>
                    <!--Logout-->
                    <li class="nav-item dropdown user-menu">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
                            <?php if(!empty(auth()->user()->staff->IMAGE)): ?>
                            <img src="<?php echo e(asset(auth()->user()->staff->IMAGE)); ?>" class="user-image img-circle elevation-2"
                                alt="User Image">
                            <?php else: ?>
                            <img src="<?php echo e(asset('frontend/img/user.png')); ?>" class="user-image img-circle elevation-2"
                                alt="User Image">
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <!-- User image -->
                            <li class="user-header bg-white">
                                <img src="<?php echo e(asset('frontend/img/user.png')); ?>" class="img-circle elevation-2"
                                    alt="User Image">
                                <p>ທ້າວ ຈີຢີຢ່າງ ມົວສື</p>
                            </li>
                            <!-- Menu Footer-->
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.auth.logout-component', [])->html();
} elseif ($_instance->childHasBeenRendered('ijuvHYl')) {
    $componentId = $_instance->getRenderedChildComponentId('ijuvHYl');
    $componentTag = $_instance->getRenderedChildComponentTagName('ijuvHYl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ijuvHYl');
} else {
    $response = \Livewire\Livewire::mount('backend.auth.logout-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('ijuvHYl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </ul>
                    </li>
                </ul>
                <button class="navbar-toggler order-1" type="button" data-toggle="collapse"
                    data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
        </nav>
        <!-- /.navbar -->
        <div class="content-wrapper">
            <?php echo e($slot); ?>

        </div>
        <!-- /.content-wrapper -->
        <footer class="main-footer">
            <strong>ເລີ່ມວັນທີ:01/11/2022 <a href="https://www.facebook.com/FNS.NUOL.edu.la/">cnms</a></strong>
            <div class="float-right d-none d-sm-inline-block">
                <b>&copy;Phonepanya Dev&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Version</b>1.1.0
            </div>
        </footer>
        <!-- Control Sidebar -->
        <aside class="control-sidebar control-sidebar-dark">
            <!-- Control sidebar content goes here -->
        </aside>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->
    <!-- jQuery -->
    <script src="<?php echo e(asset('assets/jquery/jquery.min.js')); ?>"></script>
    <!-- jQuery UI 1.11.4 -->
    <script>
    $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- ChartJS -->
    <script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
    <!-- Sparkline -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <!-- JQVMap -->
    <script src="<?php echo e(asset('assets/js/adminlte.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>
    <!-- daterangepicker -->
    <script src="<?php echo e(asset('assets/js/jquery.overlayScrollbars.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <!-- Tempusdominus Bootstrap 4 -->
    <script src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
    <!-- Summernote -->
    <script src="<?php echo e(asset('assets/js/summernote-bs4.min.js')); ?>"></script>
    <!-- overlayScrollbars -->
    <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/28.0.0/classic/ckeditor.js"></script>
    <script src="<?php echo e(asset('admin/plugins/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script>
    function labelFormatter(label, series) {
        return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">' +
            label +
            '<br>' +
            Math.round(series.percent) + '%</div>'
    }
    </script>
    <script>
    $(function() {
        // Summernote
        $('#summernote').summernote()
        $('.select2').select2()
        //Initialize Select2 Elements
        $('.select2bs4').select2({
            theme: 'bootstrap4'
        })
        $("#example1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "buttons": ["excel", "print"]
            //"buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });
    </script>
    <script>
    window.livewire.on('alert', param => {
        toastr[param['type']](param['message'], param['type']);
    });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <!-- AdminLTE App -->
</body>

</html><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/layouts/back-end.blade.php ENDPATH**/ ?>