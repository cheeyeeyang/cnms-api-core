<div>
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <b>ຈັດການຂໍ້ມູນນັກສຶກສາ</b>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
            <li class="breadcrumb-item active">ຈັດການຂໍ້ມູນນັກສຶກສາ</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <!--staffs -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
            <div class="card-header">
              <div class="row">
                <div class="col-md-8">
                  <div class="row">
                    <div class="col-md-6">
                      <!-- <a wire:click="create" class="btn btn-success" href="javascript:void(0)"><i class="fa fa-plus"></i>ເພີ່ມໃໝ່</a> -->
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <input wire:model="search" type="text" class="form-control" placeholder="ຄົ້ນຫາ">
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                  <tr style="text-align: center">
                    <th>ລໍາດັບ</th>
                    <th>ລະຫັດນັກສຶກສາ</th>
                    <th>ເພດ</th>
                    <th>ຊື່</th>
                    <th>ນາມສະກຸນ</th>
                    <th>ເບີໂທ</th>
                    <th>ວັນເດືອນປີເກີດ</th>
                    <th>ສາຂາ</th>
                    <th>ປຸ່ມຄໍາສັ່ງ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $i = 1;
                    ?>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                        <td style="text-align: center"><?php echo e($item->TITLE); ?></td>
                        <td>
                           <?php echo e($item->FRTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->LSTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->PHONE); ?>

                        </td>
                        <td style="text-align:center">
                           <?php echo e(date('d-m-Y', strtotime($item->BIRTHDATE))); ?>

                        </td>
                        <td>
                            <?php if(!empty($item->COURSENAME)): ?>
                               <?php echo e($item->COURSENAME); ?>

                            <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                                  <button wire:click="showView('<?php echo e($item->STDID); ?>')" type="button" class="btn btn-primary btn-sm"><i class="fas fa-eye"></i></button>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div>
                 <?php echo e($students->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <!-- /.modal-add staff -->
  <!-- <div wire:ignore.self class="modal fade" id="modal-add-staff">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">ເພີ່ມຂໍ້ມູນນັກສຶກສາ</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form>
        <div class="row">
             <div class="col-md-2">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ຫເພດ</label>
                    <select id="" wire:model="TITLE" class="form-control <?php $__errorArgs = ['TITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                          <option value="">ເລືອກ</option>
                          <option value="ປທ">ທ້າວ</option>
                          <option value="ປອ">ນາງ</option>
                          <option value="ອຈ.ປທ">ສນ</option>
                          <option value="ອຈ.ປອ">ພຣະ</option>
                    </select>
                        <?php $__errorArgs = ['TITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
            <div class="col-md-4">
              <div class="form-group">
                  <label><span style="color:red;">*</span>ຊື່ນັກສຶກສາ</label>
                  <input wire:model="FRTNAME" type="text" placeholder="ຊື່ລາວ" class="form-control <?php $__errorArgs = ['FRTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['FRTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="col-md-6">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ນາມສະກຸນ</label>
                        <input wire:model="LSTNAME" type="text" placeholder="ນາມສະກຸນລາວ" class="form-control <?php $__errorArgs = ['LSTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['LSTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            </div>
        </div>
        <div class="row">
              <div class="col-md-2">
                    <div class="form-group">
                            <label><span style="color:red;">*</span>Gender</label>
                            <select id="" wire:model="ETITLE" class="form-control <?php $__errorArgs = ['ETITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Mr</option>
                                <option value="ປທ">Ms</option>
                                <option value="ປອ">Mong</option>
                            </select>
                                <?php $__errorArgs = ['ETITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-5">
                  <div class="form-group">
                      <label><span style="color:red;">*</span>ຊື່ອັງກິດ</label>
                      <input wire:model="EFRTNAME" type="text" placeholder="ຊື່ອັງກິດ" class="form-control <?php $__errorArgs = ['EFRTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                      <?php $__errorArgs = ['EFRTNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ນາມສະກຸນອັງກິດ</label>
                        <input wire:model="ELNAME" type="text" placeholder="ນາມສະກຸນອັງກິດ" class="form-control <?php $__errorArgs = ['ELNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['ELNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
        </div>
        <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ວັນເດືອນປີເກີດ</label>
                        <input wire:model="BIRTHDATE" type="date" class="form-control <?php $__errorArgs = ['BIRTHDATE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['BIRTHDATE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ບ່ອນເກີດ</label>
                        <input wire:model="BIRTHADDR" type="text" class="form-control <?php $__errorArgs = ['BIRTHADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['BIRTHADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ທີ່ຢູ່ປັດຈຸບັນ</label>
                        <input wire:model="CURRADDR" type="text" class="form-control <?php $__errorArgs = ['CURRADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['CURRADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ເບີໂທ</label>
                        <input wire:model="PHONE" type="text" placeholder="ເບີໂທ" class="form-control <?php $__errorArgs = ['PHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['PHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ອີເມວ</label>
                        <input wire:model="EMAIL" type="text" placeholder="ອີເມວ" class="form-control <?php $__errorArgs = ['EMAIL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['EMAIL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ສາຂາ</label>
                    <select id="" wire:model="COURSEID" class="form-control <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                         <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->COURSEID); ?>"><?php echo e($item->COURSENAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ກອງທຶນ</label>
                        <input wire:model="FUND" type="text" placeholder="ກອງທຶນ" class="form-control <?php $__errorArgs = ['FUND'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FUND'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ພອນສະຫວັນ</label>
                        <input wire:model="TALENT" type="text" placeholder="ພອນສະຫວັນ" class="form-control <?php $__errorArgs = ['TALENT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['TALENT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຜ່ານມາເຄີຍເປັນ</label>
                        <input wire:model="BEFOREUNIV" type="text" placeholder="ຜ່ານມາເຄີຍເປັນ" class="form-control <?php $__errorArgs = ['BEFOREUNIV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['BEFOREUNIV'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ເປົ້າໝາຍ</label>
                        <input wire:model="FUTUREWISH" type="text" placeholder="ເປົ້າໝາຍ" class="form-control <?php $__errorArgs = ['FUTUREWISH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FUTUREWISH'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTPERSON" type="text" placeholder="ຜູ້ປົກຄອງ" class="form-control <?php $__errorArgs = ['CONTPERSON'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['CONTPERSON'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ສາຍພົວພັນ</label>
                        <input wire:model="RELATION" type="text" placeholder="ສາຍພົວພັນ" class="form-control <?php $__errorArgs = ['RELATION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['RELATION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ທີ່ຢູ່ຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTADDR" type="text" placeholder="ທີ່ຢູ່ຜູ້ປົກຄອງ" class="form-control <?php $__errorArgs = ['CONTADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['CONTADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ເບີໂທຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTPHONE" type="text" placeholder="ເບີໂທຜູ້ປົກຄອງ" class="form-control <?php $__errorArgs = ['CONTPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['CONTPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຊື່ພໍ່</label>
                        <input wire:model="FATHERNAME" type="text" placeholder="ຊື່ພໍ່" class="form-control <?php $__errorArgs = ['FATHERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FATHERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ອາຍຸພໍ່</label>
                        <input wire:model="FATHERAGE" type="text" placeholder="ອາຍຸພໍ່" class="form-control <?php $__errorArgs = ['FATHERAGE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FATHERAGE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ອາຊີບ</label>
                        <input wire:model="FATHEROCC" type="text" placeholder="ອາຊີບ" class="form-control <?php $__errorArgs = ['FATHEROCC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FATHEROCC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ທີ່ຢູ່ພໍ່</label>
                        <input wire:model="FATHERADDR" type="text" placeholder="ທີ່ຢູ່ພໍ່" class="form-control <?php $__errorArgs = ['FATHERADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FATHERADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ເບີໂທພໍ່</label>
                        <input wire:model="FATHERPHONE" type="text" placeholder="ເບີໂທພໍ່" class="form-control <?php $__errorArgs = ['FATHERPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['FATHERPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຊື່ແມ່</label>
                        <input wire:model="MOTHERNAME" type="text" placeholder="ຊື່ແມ່" class="form-control <?php $__errorArgs = ['MOTHERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['MOTHERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ອາຍຸແມ່</label>
                        <input wire:model="MOTHERAGE" type="text" placeholder="ອາຍຸແມ່" class="form-control <?php $__errorArgs = ['MOTHERAGE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['MOTHERAGE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ອາຊີບແມ່</label>
                        <input wire:model="MOTHEROCC" type="text" placeholder="ອາຊີບແມ່" class="form-control <?php $__errorArgs = ['MOTHEROCC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['MOTHEROCC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ທີ່ຢູ່ປັດຈຸບັນແມ່</label>
                        <input wire:model="MOTHERADDR" type="text" placeholder="ທີ່ຢູ່ປັດຈຸບັນແມ່" class="form-control <?php $__errorArgs = ['MOTHERADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['MOTHERADDR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ເບີໂທແມ່</label>
                        <input wire:model="MOTHERPHONE" type="text" placeholder="ເບີໂທແມ່" class="form-control <?php $__errorArgs = ['MOTHERPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['MOTHERPHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຊົນຊາດ</label>
                        <input wire:model="ORIGIN" type="text" placeholder="ຊົນຊາດ" class="form-control <?php $__errorArgs = ['ORIGIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['ORIGIN'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ສັນຊາດ</label>
                        <input wire:model="NATION" type="text" placeholder="ສັນຊາດ" class="form-control <?php $__errorArgs = ['NATION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['NATION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ສະຖານະ</label>
                        <input wire:model="ETHNIC" type="text" placeholder="ເບີໂທແມ່" class="form-control <?php $__errorArgs = ['ETHNIC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['ETHNIC'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ສາສະໜາ</label>
                        <input wire:model="RELIGION" type="text" placeholder="ສາສະໜາ" class="form-control <?php $__errorArgs = ['RELIGION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['RELIGION'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ຮູບແບບຈ່າຍເງິນ</label>
                        <input wire:model="STYPE" type="text" placeholder="ຮູບແບບຈ່າຍເງິນ" class="form-control <?php $__errorArgs = ['STYPE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['STYPE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ສະຖານະ</label>
                        <input wire:model="STATUS" type="checkbox" placeholder="">&nbsp;ໂສດ  <br>
                        <input wire:model="STATUS" type="checkbox" placeholder="">&nbsp;ແຕ່ງງານແລ້ວ
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label><span style="color:red;">*</span>ມາຈາກ</label>
                        <input wire:model="CFROM" type="text" placeholder="ມາຈາກ" class="form-control <?php $__errorArgs = ['CFROM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                        <?php $__errorArgs = ['CFROM'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        </form>
     </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
          <button type="button" wire:click="store" class="btn btn-success"><i class="fas fa-download"></i>&nbsp;ບັນທຶກ</button>
        </div>
      </div>
    </div>
  </div> -->
<!-- /.modal-edit staff -->
<div wire:ignore.self class="modal fade" id="modal-edit-staff">
    
  </div>
<!-- /.modal-delete staff-->
<div wire:ignore.self class="modal fade" id="modal-delete-staff">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">ທ່ານຕ້ອງການລຶບຂໍ້ມນີ້ບໍ</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <div class="modal-body">
                <div class="text-center">
                      <h6 class="mt-2">ຊື່ ແລະ ນາມສະກຸນ: </h6>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
                        <button wire:click="destroyStore" type="button" class="btn btn-danger"><i class="fa fa-times-circle" aria-hidden="true"></i>&nbsp;ລຶບ</button>
            </div>
      </div>
    </div>
  </div>
</div>
<!-- /.modal-view staff -->
   <div wire:ignore.self class="modal fade" id="modal-view-staff">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">ລາຍລະອຽດຂໍ້ມູນນັກສຶກສາ</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form>
        <div class="row">
             <div class="col-md-2">
                    <div class="form-group">
                    <label> ເພດ</label>
                    <input type="text" id="" wire:model="TITLE" class="form-control" disabled>
                    </div>
              </div>
            <div class="col-md-5">
              <div class="form-group">
                  <label>ຊື່ນັກສຶກສາ</label>
                  <input wire:model="FRTNAME" type="text"  class="form-control" disabled>
              </div>
            </div>
            <div class="col-md-5">
                    <div class="form-group">
                        <label>ນາມສະກຸນ</label>
                        <input wire:model="LSTNAME" type="text"  class="form-control" disabled>
                    </div>
            </div>
        </div>
        <div class="row">
              <div class="col-md-2">
                    <div class="form-group">
                            <label>Gender</label>
                            <input id="" type="text" wire:model="ETITLE" class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-5">
                  <div class="form-group">
                      <label>ຊື່ອັງກິດ</label>
                      <input wire:model="EFNAME" type="text" placeholder="ຊື່ອັງກິດ" class="form-control" disabled>
                  </div>
                </div>
                <div class="col-md-5">
                    <div class="form-group">
                        <label>ນາມສະກຸນອັງກິດ</label>
                        <input wire:model="ELNAME" type="text" class="form-control" disabled>
                    </div>
                </div>
        </div>
        <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>ວັນເດືອນປີເກີດ</label>
                        <input wire:model="BIRTHDATE" type="date" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>ບ່ອນເກີດ</label>
                        <input wire:model="BIRTHADDR" type="text" class="form-control" disabled>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>ທີ່ຢູ່ປັດຈຸບັນ</label>
                        <input wire:model="CURRADDR" type="text" class="form-control" disabled> 
                    </div>
                </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ເບີໂທ</label>
                        <input wire:model="PHONE" type="text" placeholder="ເບີໂທ" class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ອີເມວ</label>
                        <input wire:model="EMAIL" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                    <label> ສາຂາ</label>
                    <input type="text" wire:model="COURSEID" class="form-control" disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ທຶນການສຶກສາ</label>
                        <input wire:model="FUND" type="text" class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ພອນສະຫວັນ</label>
                        <input wire:model="TALENT" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ຜ່ານມາເຄີຍເປັນ</label>
                        <input wire:model="BEFOREUNIV" type="text"  class="form-control" disabled> 
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ເປົ້າໝາຍ</label>
                        <input wire:model="FUTUREWISH" type="text"  class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTPERSON" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ສາຍພົວພັນ</label>
                        <input wire:model="RELATION" type="text"  class="form-control" disabled>
                    </div>
              </div>
              
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ທີ່ຢູ່ຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTADDR" type="text"  class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ເບີໂທຜູ້ປົກຄອງ</label>
                        <input wire:model="CONTPHONE" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ຊື່ພໍ່</label>
                        <input wire:model="FATHERNAME" type="text" class="form-control" disabled>
                    </div>
              </div>
              
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ອາຍຸພໍ່</label>
                        <input wire:model="FATHERAGE" type="text" class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ອາຊີບ</label>
                        <input wire:model="FATHEROCC" type="text" placeholder="ອາຊີບ" class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ທີ່ຢູ່ພໍ່</label>
                        <input wire:model="FATHERADDR" type="text"  class="form-control" disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ເບີໂທພໍ່</label>
                        <input wire:model="FATHERPHONE" type="text"  class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ຊື່ແມ່</label>
                        <input wire:model="MOTHERNAME" type="text" class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ອາຍຸແມ່</label>
                        <input wire:model="MOTHERAGE" type="text"  class="form-control" disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ອາຊີບແມ່</label>
                        <input wire:model="MOTHEROCC" type="text" class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ທີ່ຢູ່ປັດຈຸບັນແມ່</label>
                        <input wire:model="MOTHERADDR" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ເບີໂທແມ່</label>
                        <input wire:model="MOTHERPHONE" type="text"  class="form-control" disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ຊົນຊາດ</label>
                        <input wire:model="ORIGIN" type="text"  class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ສັນຊາດ</label>
                        <input wire:model="NATION" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ຊົນເຜົ່າ</label>
                        <input wire:model="ETHNIC" type="text"  class="form-control" disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-4">
                    <div class="form-group">
                        <label>ສາສະໜາ</label>
                        <input wire:model="RELIGION" type="text"  class="form-control" disabled>
                    </div>
              </div>
               <div class="col-md-4">
                    <div class="form-group">
                        <label>ຮູບແບບຈ່າຍເງິນ</label>
                        <input wire:model="STYPE" type="text"  class="form-control" disabled>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group">
                        <label>ສະຖານະ</label>
                        <input wire:model="STATUS" type="text" class="form-control"  disabled>
                    </div>
              </div>
        </div>
        <div class="row">
             <div class="col-md-12">
                    <div class="form-group">
                        <label>ມາຈາກ</label>
                        <input wire:model="CFROM" type="text" placeholder="ມາຈາກ" class="form-control" disabled>
                    </div>
              </div>
        </div>
        </form>
     </div>
        <div class="modal-footer text-right">
          <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->startPush('scripts'); ?>
  <script>
    //Add staff
    window.addEventListener('show-modal-add-staff', event => {
      $('#modal-add-staff').modal('show');
    })
    window.addEventListener('hide-modal-add-staff', event => {
      $('#modal-add-staff').modal('hide');
    })
    //Edit staff
    window.addEventListener('show-modal-edit-staff', event => {
      $('#modal-edit-staff').modal('show');
    })
    window.addEventListener('hide-modal-edit-staff', event => {
      $('#modal-edit-staff').modal('hide');
    })
    //Delete staff
    window.addEventListener('show-modal-delete-staff', event => {
      $('#modal-delete-staff').modal('show');
    })
    window.addEventListener('hide-modal-delete-staff', event => {
      $('#modal-delete-staff').modal('hide');
    })
    //View staff
    window.addEventListener('show-modal-view-staff', event => {
      $('#modal-view-staff').modal('show');
    });
  </script>
<?php $__env->stopPush(); ?>
  </div>
</div>

<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/setting/student-component.blade.php ENDPATH**/ ?>