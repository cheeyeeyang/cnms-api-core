<div>
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <b>ຈັດການຂໍ້ມູນສາຂາ</b>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
            <li class="breadcrumb-item active">ຈັດການຂໍ້ມູນສາຂາ</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <!--courses -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
            <div class="card-header">
              <div class="row">
                <div class="col-md-8">
                  <div class="row">
                    <div class="col-md-6">
                      <a wire:click="create" class="btn btn-success" href="javascript:void(0)"><i class="fa fa-plus"></i>ເພີ່ມໃໝ່</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <input wire:model="search" type="text" class="form-control" placeholder="ຄົ້ນຫາ">
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                  <tr style="text-align: center">
                    <th>ລໍາດັບ</th>
                    <th>ລະຫັດ</th>
                    <th>ຊື່ສາຂາ</th>
                    <th>ລະດັບ</th>
                    <th>ພາກວິຊາ</th>
                    <th>ປຸ່ມຄໍາສັ່ງ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $i = 1;
                    ?>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->COURSEID); ?></td>
                        <td><?php echo e($item->COURSENAME); ?></td>
                        <td>
                           <?php echo e($item->LEVEL); ?>

                        </td>
                        <td>
                           <?php if(!empty($item->department->DEPTNAME)): ?>
                             <?php echo e($item->department->DEPTNAME); ?>

                           <?php endif; ?>
                        </td>
                        <td style="text-align:center">
                                  <button wire:click="showedit('<?php echo e($item->COURSEID); ?>')" type="button" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                  <button wire:click="showDestroy('<?php echo e($item->COURSEID); ?>')" type="button" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div>
                 <?php echo e($courses->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  <!-- /.modal-add course -->
  <div wire:ignore.self class="modal fade" id="modal-add-course">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">ເພີ່ມຂໍ້ມູນສາຂາ</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form>
        <div class="row">
           <div class="col-md-6">
              <div class="form-group">
                  <label><span style="color:red;">*</span> ລະຫັດສາຂາ</label>
                  <input wire:model="COURSEID" type="text" placeholder="ລະຫັດສາຂາ" class="form-control <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                  <label><span style="color:red;">*</span> ຊື່ສາຂາ</label>
                  <input wire:model="COURSENAME" type="text" placeholder="ຊື່ສາຂາ" class="form-control <?php $__errorArgs = ['COURSENAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['COURSENAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ລະດັບ</label>
                    <select id="" wire:model="LEVEL" class="form-control <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                          <option value="ປະລິນຍາຕີ">ປະລິນຍາຕີ</option>
                          <option value="ປະລິນຍາໂທ">ປະລິນຍາໂທ</option>
                          <option value="ປະລິນຍາເອກ">ປະລິນຍາເອກ</option>
                    </select>
                        <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-6">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ພາກວິຊາ</label>
                    <select id="" wire:model="DEPTID" class="form-control <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                         <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->DEPTID); ?>"><?php echo e($item->DEPTNAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        </form>
     </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
          <button type="button" wire:click="store" class="btn btn-success"><i class="fas fa-download"></i>&nbsp;ບັນທຶກ</button>
        </div>
      </div>
    </div>
  </div>
<!-- /.modal-add course -->
<div wire:ignore.self class="modal fade" id="modal-edit-course">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">ແກ້ໄຂຂໍ້ມູນສາຂາ</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form>
        <div class="row">
           <div class="col-md-6">
              <div class="form-group">
                  <label><span style="color:red;">*</span> ລະຫັດສາຂາ</label>
                  <input wire:model="COURSEID" type="text" placeholder="ລະຫັດສາຂາ" class="form-control <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                  <label><span style="color:red;">*</span> ຊື່ສາຂາ</label>
                  <input wire:model="COURSENAME" type="text" placeholder="ຊື່ສາຂາ" class="form-control <?php $__errorArgs = ['COURSENAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['COURSENAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ລະດັບ</label>
                    <select id="" wire:model="LEVEL" class="form-control <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                          <option value="ປະລິນຍາຕີ">ປະລິນຍາຕີ</option>
                          <option value="ປະລິນຍາໂທ">ປະລິນຍາໂທ</option>
                          <option value="ປະລິນຍາເອກ">ປະລິນຍາເອກ</option>
                    </select>
                        <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-6">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ພາກວິຊາ</label>
                    <select id="" wire:model="DEPTID" class="form-control <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                         <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->DEPTID); ?>"><?php echo e($item->DEPTNAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['DEPTID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        </form>
     </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
          <button type="button" wire:click="Update" class="btn btn-success"><i class="fas fa-download"></i>&nbsp;ບັນທຶກ</button>
        </div>
      </div>
    </div>
  </div>
<!-- /.modal-delete course-->
<div wire:ignore.self class="modal fade" id="modal-delete-course">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">ທ່ານຕ້ອງການລຶບຂໍ້ມນີ້ບໍ</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <div class="modal-body">
                  <h4>ລະຫັດສາຂາ: <?php echo e($this->COURSEID); ?></h4>
                  <h4>ຊື່ສາຂາ: <?php echo e($this->COURSENAME); ?></h4>
            </div>
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
                        <button wire:click="destroyStore" type="button" class="btn btn-danger"><i class="fa fa-times-circle" aria-hidden="true"></i>&nbsp;ລຶບ</button>
            </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->startPush('scripts'); ?>
  <script>
    //Add course
    window.addEventListener('show-modal-add-course', event => {
      $('#modal-add-course').modal('show');
    })
    window.addEventListener('hide-modal-add-course', event => {
      $('#modal-add-course').modal('hide');
    })
    //Edit course
    window.addEventListener('show-modal-edit-course', event => {
      $('#modal-edit-course').modal('show');
    })
    window.addEventListener('hide-modal-edit-course', event => {
      $('#modal-edit-course').modal('hide');
    })
    //Delete course
    window.addEventListener('show-modal-delete-course', event => {
      $('#modal-delete-course').modal('show');
    })
    window.addEventListener('hide-modal-delete-course', event => {
      $('#modal-delete-course').modal('hide');
    })
    //View course
    window.addEventListener('show-modal-view-course', event => {
      $('#modal-view-course').modal('show');
    });
  </script>
<?php $__env->stopPush(); ?>
  </div>
</div>

<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/setting/course-component.blade.php ENDPATH**/ ?>