<div>
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <b>ຕັ້ງຄ່າຂໍ້ມູນັກສຶກສາເຂົ້າລະບົບ</b>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
            <li class="breadcrumb-item active">ຕັ້ງຄ່າຂໍ້ມູນັກສຶກສາເຂົ້າລະບົບ</li>
          </ol>
        </div>
      </div>
    </div>
  </section>
  <div class="content">
    <div class="container-fluid">
       <div class="row">
        <div class="col-md-12">
           <div class="card">
              <div class="card-header">
                <?php if(!empty($this->hiddenId)): ?>
                   <h4>ແກ້ໄຂຂໍ້ມູນຄະນະຫ້ອງ</h4>
                <?php else: ?>
                   <h4>ເພີ່ມຂໍ້ມູນຄະນະຫ້ອງ</h4>
                <?php endif; ?>
              </div>
              <div class="card-body">
              <form>
        <div class="row">
            <div class="col-md-4">
                    <div class="form-group" wire:ignore>
                    <label><span style="color:red;">*</span> ສາຂາ</label>
                    <select id="selectcourse" wire:model="COURSEID" class="form-control <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->COURSEID); ?>"><?php echo e($item->COURSENAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['COURSEID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
            </div>
            <div class="col-md-4">
                   <div class="form-group">
                    <label><span style="color:red;">*</span> ປີທີ</label>
                    <select id="" wire:model="YLEVEL" class="form-control <?php $__errorArgs = ['YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="1">1</option>
                         <option value="2">2</option>
                         <option value="3">3</option>
                         <option value="4">4</option>
                    </select>
                        <?php $__errorArgs = ['YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                    <div class="form-group" wire:ignore>
                    <label><span style="color:red;">*</span> ສົກຮຽນ</label>
                    <select id="selectacyear" wire:model="ACYEAR" class="form-control <?php $__errorArgs = ['ACYEAR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->ACID); ?>"><?php echo e($item->ACNAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['ACYEAR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
              <div class="col-md-4">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ຫ້ອງ</label>
                    <select id="selectacyear" wire:model="GRID" class="form-control <?php $__errorArgs = ['GRID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->Group); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['GRID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-4">
                  <?php if(!empty($this->hiddenId)): ?>
                    <div class="form-group">
                      <label><span style="color:red;">*</span> ລະຫັດນັກສຶກສາ</label>
                      <input id="selectStudent" wire:model="st_fullname"  class="form-control" disabled>
                     </div>
                    <?php else: ?>
                    <div class="form-group">
                         <label><span style="color:red;">*</span> ລະຫັດນັກສຶກສາ</label>
                        <select id="selectStudent" wire:model="STDUSER"  class="form-control <?php $__errorArgs = ['STDUSER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($item->STDID)): ?>
                                    <option value="<?php echo e($item->STDID); ?>"><?php echo e($item->STDID); ?> <?php echo e($item->TITLE); ?> <?php echo e($item->FRTNAME); ?> <?php echo e($item->LSTNAME); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['STDUSER'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <?php endif; ?>
            </div>
              <div class="col-md-4">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ຄະນະຫ້ອງຜູ້ທີ</label>
                    <select id="" wire:model="LEVEL" class="form-control <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                         <option value="1">1</option>
                         <option value="2">2</option>
                         <option value="3">3</option>
                    </select>
                        <?php $__errorArgs = ['LEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
        </div>
        <div class="row">
                  <div class="col-md-12">
                  <?php if(!empty($this->hiddenId)): ?>
                      <a href="#" wire:click="store" class="btn btn-success btn-sm w-100"><i class="fas fa-pen"></i> ແກ້ໄຂ</a>
                  <?php else: ?>
                      <a href="#" wire:click="store" class="btn btn-primary btn-sm w-100"><i class="fas fa-download"></i> ບັນທຶກ</a>
                  <?php endif; ?>
                  </div>
        </div>
        </form>
              </div>
           </div>
       </div>
     </div>
      <div class="row">
        <!--studentlogins -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
            <div class="card-header">
              <div class="row">
                <div class="col-md-8">
                  <div class="row">
                    <div class="col-md-6">
                      <a wire:click="clickImport" class="btn btn-success" href="javascript:void(0)"><i class="fa fa-plus"></i>ດຶງຂໍ້ມູນນັກສຶກສາທັງໝົດ</a>
                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <input wire:model="search" type="text" class="form-control" placeholder="ຄົ້ນຫາ">
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                  <tr style="text-align: center">
                    <th>ລໍາດັບ</th>
                    <th>ລະຫັດນັກສຶກສາ</th>
                    <th>ຊື່ ແລະ ນາມສະກຸນ</th>
                    <th>ຫ້ອງ</th>
                    <th>ປີ</th>
                    <th>ສົກຮຽນ</th>
                    <th>ສາຂາ</th>
                    <th>ສະຖານະ</th>
                    <th>ປຸ່ມຄໍາສັ່ງ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $i = 1;
                    ?>
                    <?php $__currentLoopData = $studentlogins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDUSER); ?></td>
                        <td><?php echo e($item->TITLE); ?> <?php echo e($item->FRTNAME); ?> <?php echo e($item->LSTNAME); ?></td>
                        <td>
                          <?php echo e($item->Group); ?>

                        </td>
                        <td style="text-align: center">
                           <?php echo e($item->YLEVEL); ?>

                        </td>
                        <td style="text-align: center">
                        <?php echo e($item->ACYEAR); ?>

                        </td>
                        <td>
                            <?php if(!empty($item->COURSENAME)): ?>
                               <?php echo e($item->COURSENAME); ?>

                            <?php endif; ?>
                        </td>
                        <td style="text-align: center">
                        <?php if($item->LEVEL ==0): ?>
                           ສະມາຊິກ
                        <?php else: ?>
                             ຄະນະຫ້ອງຜູ້ທີ <?php echo e($item->LEVEL); ?>

                        <?php endif; ?>
                      </td>
                        <td style="text-align:center">
                                  <button wire:click="showedit('<?php echo e($item->STDUSER); ?>')" type="button" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                  <button wire:click="showDestroy('<?php echo e($item->STDUSER); ?>')" type="button" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                        </td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div>
                 <?php echo e($studentlogins->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<div wire:ignore.self class="modal fade" id="modal-delete-studentlogin">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">ທ່ານຕ້ອງການລຶບຂໍ້ມນີ້ບໍ</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <div class="modal-body">
                  <h4>ລະຫັດນັກສຶກສາ: <?php echo e($this->STDUSER); ?></h4>
            </div>
            <div class="modal-footer justify-content-between">
            <button type="button" class="btn btn-primary" data-dismiss="modal"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ຍົກເລີກ</button>
                        <button wire:click="destroyStore" type="button" class="btn btn-danger"><i class="fa fa-times-circle" aria-hidden="true"></i>&nbsp;ລຶບ</button>
            </div>
      </div>
    </div>
  </div>
</div>
<div wire:ignore.self class="modal fade" id="modal-add-studentlogin">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title">ດຶງຂໍ້ມູນນັກສຶກສາທັງໝົດ</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
            <div class="modal-body">
                  <form action="">
                    <div class="row">
                    <div class="col-md-6">
                   <div class="form-group">
                    <label><span style="color:red;">*</span> ປີທີ</label>
                    <select id="" wire:model="p_YLEVEL" class="form-control <?php $__errorArgs = ['p_YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                         <option value="">ເລືອກ</option>
                         <option value="1">1</option>
                         <option value="2">2</option>
                         <option value="3">3</option>
                         <option value="4">4</option>
                    </select>
                        <?php $__errorArgs = ['p_YLEVEL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
              <div class="col-md-6">
                    <div class="form-group">
                    <label><span style="color:red;">*</span> ສົກຮຽນ</label>
                    <select id="selectacyear" wire:model="p_ACYEAR" class="form-control <?php $__errorArgs = ['p_ACYEAR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                       <option value="">ເລືອກ</option>
                        <?php $__currentLoopData = $acyears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->ACID); ?>"><?php echo e($item->ACNAME); ?></option>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        <?php $__errorArgs = ['p_ACYEAR'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
              </div>
                    </div>
                  </form>
            </div>
            <div class="modal-footer justify-content-between">
                  <a href="#" wire:click="ImportAll" class="btn btn-success btn-sm w-100">ບັນທຶກ</a>
            </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->startPush('scripts'); ?>
  <script>
    //Add course
    window.addEventListener('show-modal-add-studentlogin', event => {
      $('#modal-add-studentlogin').modal('show');
    })
    window.addEventListener('hide-modal-add-studentlogin', event => {
      $('#modal-add-studentlogin').modal('hide');
    })
    //Edit course
    window.addEventListener('show-modal-edit-studentlogin', event => {
      $('#modal-edit-studentlogin').modal('show');
    })
    window.addEventListener('hide-modal-edit-studentlogin', event => {
      $('#modal-edit-studentlogin').modal('hide');
    })
    //Delete course
    window.addEventListener('show-modal-delete-studentlogin', event => {
      $('#modal-delete-studentlogin').modal('show');
    })
    window.addEventListener('hide-modal-delete-studentlogin', event => {
      $('#modal-delete-studentlogin').modal('hide');
    })
  </script>
   <script>
            $(document).ready(function() {
                $("#selectStudent").select2();
                $('#selectStudent').on('change', function(e) {
                var data = $('#selectStudent').select2("val");
                window.livewire.find('<?php echo e($_instance->id); ?>').set('STDUSER',data);
                });
                $("#selectcourse").select2();
                $('#selectcourse').on('change', function(e) {
                var data = $('#selectcourse').select2("val");
                window.livewire.find('<?php echo e($_instance->id); ?>').set('COURSEID',data);
                });
                $("#selectacyear").select2();
                $('#selectacyear').on('change', function(e) {
                var data = $('#selectacyear').select2("val");
                window.livewire.find('<?php echo e($_instance->id); ?>').set('ACYEAR',data);
                });
            });
        </script>
<?php $__env->stopPush(); ?>
  </div>
</div>

<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/setting/studentlogin-component.blade.php ENDPATH**/ ?>