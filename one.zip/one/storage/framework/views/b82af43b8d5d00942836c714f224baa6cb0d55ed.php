<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><b>ລາຍຊື່ນັກສຶກສາຂອງຫ້ອງ <?php if(!empty($this->group)): ?> <?php echo e($this->group); ?> <?php endif; ?></b></h5>
            </div>
            <div class="card-body">
                <div class="row">
                        <div class="col-md-3 p-1">
                            <input wire:model="search" type="text" class="form-control" placeholder="ຄົ້ນຫາ">
                        </div>
                </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center"> ເລືອກ</th>
                    <th style="text-align: center">ລ/ດ</th>
                    <th  style="text-align: center">ລະຫັດນັກສຶກສາ</th>
                    <th style="text-align: center">ເພດ</th>
                    <th>ຊື່</th>
                    <th>ນາມສະກຸນ</th>
                    <th>ເບີໂທ</th>
                    <th style="text-align: center">ຂາດ</th>
                    <th style="text-align: center">ອະນຸຍາດ</th>
                    <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                     use Carbon\Carbon;
                     $i = 1;
                     $count_absent = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $check_already =  DB::table('studentabsents')->where('TBID', $this->TBID)->where('STDID', $item->STDID)->whereDate('created_at', '=', Carbon::today())->first();
                        $count_absent = DB::table('studentabsents')->where('TBID', $this->TBID)->where('STDID', $item->STDID)->WhereNull('REMARK')->count();
                        $count_allow = DB::table('studentabsents')->where('TBID', $this->TBID)->where('STDID', $item->STDID)->WhereNotNull('REMARK')->count();
                    ?>
                    <?php if($check_already): ?>
                    <tr>
                        <td style="text-align: center">
                               <i class="fa fa-check-circle text-success"></i>
                        </td>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                        <td style="text-align: center">
                            <?php echo e($item->TITLE); ?>

                        </td>
                        <td>
                           <?php echo e($item->FRTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->LSTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->PHONE); ?>

                        </td>
                        <td style="text-align: center">
                          <?php echo e($count_absent); ?>

                        </td>
                        <td style="text-align: center">
                            <?php echo e($count_allow); ?>

                        </td>
                        <td style="text-align: center">
                            <a href="#" wire:click="ShowDetail('<?php echo e($item->STDID); ?>')"><u>ລາຍລະອຽດ</u></a>
                        </td>
                    </tr>
                    <?php else: ?>
                    <tr>
                        <td style="text-align: center">
                           <div wire:ignore>
                                <input type="radio" value="<?php echo e($item->STDID); ?>" wire:model="selectOne">
                           </div>
                        </td>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                        <td style="text-align: center">
                            <?php echo e($item->TITLE); ?>

                        </td>
                        <td>
                           <?php echo e($item->FRTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->LSTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->PHONE); ?>

                        </td>
                        <td style="text-align: center">
                           <?php echo e($count_absent); ?>

                        </td>
                        <td style="text-align: center">
                           <?php echo e($count_allow); ?>

                        </td>
                        <td style="text-align: center">
                            <?php if($this->selectOne == $item->STDID): ?>
                                <input type="text" class="form-control" placeholder="ເຫດຜົນ ..." wire:model="REMARK"> <br>
                                <a href="#" class="btn btn-success btn-sm" wire:click="SaveAbsent"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;ໝາຍຂາດ</a>
                            <?php else: ?> 
                               <a href="#" wire:click="ShowDetail('<?php echo e($item->STDID); ?>')"><u>ລາຍລະອຽດ</u></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div> 
              <div>
                 <?php echo e($data->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
       <!-- show details  -->
       <div wire:ignore.self class="modal fade" id="modal-show-detail">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
              <h4 class="modal-title"> ຂໍ້ມູນລາຍລະອຽດວັນຂາດ </h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ລ/ດ</th>
                                <th style="text-align: center">ວັນທີຂາດ</th>
                                <th style="text-align: center">ລະຫັດນັກສຶກສາ</th>
                                <th style="text-align: center">ເພດ</th>
                                <th>ຊື່</th>
                                <th>ນາມສະກຸນ</th>
                                <th>ເບີໂທ</th>
                                <th>ເຫດຜົນ</th>
                                <th style="text-align: center">ສະຖານະ</th>
                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                               $i = 1;
                              ?>
                              <?php $__currentLoopData = $this->detailabsent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if(!empty($item->REMARK)): ?>
                              <tr class="text-success">
                                   <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td style="text-align: center"><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                                    <td style="text-align: center">
                                    <?php if(!empty($item->student->TITLE)): ?>
                                        <?php echo e($item->student->TITLE); ?>

                                    <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->FRTNAME)): ?>
                                      <?php echo e($item->student->FRTNAME); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->LSTNAME)): ?>
                                      <?php echo e($item->student->LSTNAME); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->PHONE)): ?>
                                      <?php echo e($item->student->PHONE); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->REMARK); ?></td>
                                    <td style="text-align: center"><p><i class="fa fa-check-circle"></i> ອະນຸຍາດ</p></td>
                             </tr>
                             <?php else: ?>
                             <tr class="text-danger">
                                   <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td style="text-align: center"><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                                    <td style="text-align: center">
                                    <?php if(!empty($item->student->TITLE)): ?>
                                        <?php echo e($item->student->TITLE); ?>

                                    <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->FRTNAME)): ?>
                                      <?php echo e($item->student->FRTNAME); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->LSTNAME)): ?>
                                      <?php echo e($item->student->LSTNAME); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td>
                                      <?php if(!empty($item->student->PHONE)): ?>
                                      <?php echo e($item->student->PHONE); ?>

                                      <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->REMARK); ?></td>
                                    <td style="text-align: center"><p><i class="fa fa-times"></i> ບໍ່ອະນຸຍາດ</p></td>
                             </tr>
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                  <td  rowspan="3" colspan="6"  style="vertical-align : middle;text-align:center;"><b>ສະຫຼຸບ</b></td>
                            </tr>
                            <tr style="text-align: center;font-weight:bold;">
                                 <td>ຂາດ</td>
                                 <td>ອະນຸຍາດ</td>
                                 <td>ລວມ</td>
                            </tr>
                              <tr style="text-align: center;font-weight:bold;">
                                 <td><u>
                                  <?php if($this->show_count_absent): ?>
                                      <?php echo e($this->show_count_absent); ?>

                                  <?php endif; ?>
                                </u></td>
                                 <td><u>
                                  <?php if($this->show_count_allow): ?>
                                      <?php echo e($this->show_count_allow); ?>

                                  <?php endif; ?>
                                 </u></td>
                                 <td><u>
                                 <?php if($this->show_count_absent || $this->show_count_allow): ?>
                                      <?php echo e($this->show_count_absent + $this->show_count_allow); ?>

                                  <?php endif; ?>
                                 </u></td>
                            </tr>
                            </tbody>
                            </table>
                        </div>
              </div>
            </div>
          </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/teacher/detail-student-component.blade.php ENDPATH**/ ?>