<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-outline card-primary">
            <div class="card-header text-center">
               <h5>ລາຍວິຊາທີ່ສອນໃນພາກຮຽນທີ <?php if(session()->get('data')['semester'] ==1): ?> I <?php else: ?> II <?php endif; ?> ສົກຮຽນ <?php echo e($this->acyear); ?> ຂອງອາຈານ <?php echo e($this->teacher); ?></h5>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລໍາດັບ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດຫ້ອງ</th>
                    <th style="text-align: center">ຊ/ມ</th>
                    <th style="text-align: center">ປະເພດຊ/ມ</th>
                    <th>ຫ້ອງ</th>
                    <th>ຈ/ນຊ/ມຂຶ້ນສອນແລ້ວ</th>
                    <th>ຈ/ນຊ/ມຍັງຕ້ອງຂຶ້ນສອນ</th>
                    <th style="text-align: center">ລາຍລະອຽດ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->where('STTID', 1)->orderBy('memos.MMID', 'desc')->get();
                    $active_hour = 0;
                    foreach($memos as $items){
                        $active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                    }
                    ?>
                    <?php if($active_hour > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->subject->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->subject->CREDIT); ?></td>
                        <td><?php echo e($item->classroom->classroomtype->NAME); ?></td>
                        <td style="text-align: center">
                              <?php if($item->time->TIME =='8:00-9:45'): ?>
                              1
                              <?php elseif($item->time->TIME =='10:00-11:30'): ?>
                              2
                              <?php elseif($item->time->TIME =='13:00-14:45'): ?>
                              3
                              <?php elseif($item->time->TIME =='15:00-16:30'): ?>
                              4
                              <?php endif; ?>
                        </td>
                        <td><?php echo e($item->time->REMARK); ?></td>
                        <td style="text-align: center"><?php echo e($item->group->Group); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?>/<?php echo e($item->NUMBER_HOUR); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($item->NUMBER_HOUR - $active_hour)); ?>/<?php echo e($item->NUMBER_HOUR); ?></td>
                        <td style="text-align: center"><a href="#" wire:click="ShowDetail('<?php echo e($item->TBID); ?>')"><u>ເບິ່ງລາຍລະອຽດ</u></a></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div class="text-left">
                   <a href="<?php echo e(route('admin.checkteacherupclass')); ?>" class="btn btn-success btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i>&nbsp;ກັບຄືນ</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- show details  -->
        <div wire:ignore.self class="modal fade" id="modal-show-detail">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
              <div class="text-center"><h5><b>ຂໍ້ມູນການຂຶ້ນຫ້ອງສອນຂອງອາຈານ <?php echo e($this->teacher); ?> ວິຊາ <?php echo e($this->subject); ?> (<?php echo e($this->classroomtype); ?>)</b></h5></div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ລໍາດັບ</th>
                                <th>ວັນ,ເດືອນ,ປີ ຂຶ້ນຫ້ອງ</th>
                                <th>ເວລາຂຶ້ນຫ້ອງ</th>
                                <th style="text-align: center">ເວລາລົງຫ້ອງ</th>
                                <th style="text-align: center">ສະຖານະ</th>
                                <th>ເຫດຜົນ</th>
                                <th>ຊື່ຄະນະຫ້ອງ</th>
                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                               $i = 1;
                              ?>
                              <?php $__currentLoopData = $this->memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                                    <td><?php echo e(date('H:i:s A', strtotime($item->DATETIME_IN))); ?></td>
                                    <td style="text-align: center"><?php echo e(date('H:i:s A', strtotime($item->DATETIME_OUT))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->status->NAME); ?></td>
                                    <td><?php echo e($item->SEASON_MORE); ?></td>
                                    <td><?php echo e($item->student->TITLE); ?> <?php echo e($item->student->FRTNAME); ?> <?php echo e($item->student->LSTNAME); ?></td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <div class="text-left font-weight-bold">
                                <p>-ຈໍານວນຊົ່ວໂມງສອນວິຊານີ້ = <?php echo e(number_format($this->all_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-success">-ຈໍານວນຊົ່ວໂມງທີ່ຂຶ້ນແລ້ວ = <?php echo e(number_format($this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-danger">-ຈໍານວນຊົ່ວໂມງສອນທີ່ຍັງຕ້ອງໄດ້ຂຶ້ນ = <?php echo e(number_format($this->all_hour - $this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                            </div>
                        </div>
              </div>
            </div>
          </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
      <!-- end -->
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/detail-check-teacher-up-class-component.blade.php ENDPATH**/ ?>