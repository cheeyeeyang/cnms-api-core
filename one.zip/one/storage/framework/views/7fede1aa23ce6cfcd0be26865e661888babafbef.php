<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
             <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('student.subject')); ?>">ໜ້າຫຼັກ</a></li>
                <li class="breadcrumb-item active">ບັນທຶກອາຈານຂຶ້ນຫ້ອງສອນ</li>
              </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
                <div class="text-center"><h5><b>ບັນທຶກການຂຶ້ນຫ້ອງສອນຂອງອາຈານ <?php echo e($this->teacher); ?> ວິຊາ <?php echo e($this->subject); ?> (<?php echo e($this->classroomtype); ?>)</b></h5></div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="">ຫ້ອງ</label>
                            <select wire:model="classroom_id" id="" class="form-control <?php $__errorArgs = ['classroom_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->NAME); ?>"><?php echo e($item->NAME); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['classroom_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" wire:ignore>
                            <label for="">ວັນ,ເດືອນ,ປີ ຂຶ້ນຫ້ອງ</label>
                            <input type="datetime-local" wire:model="date_in" class="form-control <?php $__errorArgs = ['date_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_in">
                        <?php $__errorArgs = ['date_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group" wire:ignore>
                            <label for="">ວັນ,ເດືອນ,ປີ  ລົງຫ້ອງ</label>
                            <input type="datetime-local" wire:model="date_out" class="form-control <?php $__errorArgs = ['date_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date_out">
                        <?php $__errorArgs = ['date_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div> 
                <div class="row">
                    <div class="col-md-4">
                         <div class="form-group">
                             <label for="">ເລືອກສະຖານະ</label>
                             <select wire:model="status_id" class="form-control <?php $__errorArgs = ['status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">>
                                  <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->STTID); ?>"><?php echo e($item->NAME); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                           <?php $__errorArgs = ['status_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                         </div>
                    </div>
                    <div class="col-md-8">
                         <label for="">ເຫດຜົນການຂາດ</label>
                         <textarea wire:model="season" id="" cols="30" placeholder="ເຫດຜົນການຂາດ" rows="1"  class="form-control">
                        </textarea>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12">
                      <?php if(!empty($this->hiddenId)): ?>
                         <a href="#" wire:click="edit" class="btn btn-success w-100">ແກ້ໄຂ</a>
                      <?php else: ?>
                         <a href="#" wire:click="store" class="btn btn-primary w-100">ບັນທຶກ</a>
                      <?php endif; ?>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="text-center"><h5><b>ຂໍ້ມູນການຂຶ້ນຫ້ອງສອນຂອງອາຈານ <?php echo e($this->teacher); ?> ວິຊາ <?php echo e($this->subject); ?> (<?php echo e($this->classroomtype); ?>)</b></h5></div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ລໍາດັບ</th>
                                <th>ວັນ,ເດືອນ,ປີ ຂຶ້ນຫ້ອງ</th>
                                <th>ເວລາຂຶ້ນຫ້ອງ</th>
                                <th style="text-align: center">ເວລາລົງຫ້ອງ</th>
                                <th style="text-align: center">ສະຖານະ</th>
                                <th>ເຫດຜົນ</th>
                                <th>ຊື່ຄະນະຫ້ອງ</th>
                                <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                  $i = 1;
                                ?>
                                <?php $__currentLoopData = $memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                                    <td><?php echo e(date('H:i:s A', strtotime($item->DATETIME_IN))); ?></td>
                                    <td style="text-align: center"><?php echo e(date('H:i:s A', strtotime($item->DATETIME_OUT))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->status->NAME); ?></td>
                                    <td><?php echo e($item->SEASON_MORE); ?></td>
                                    <td><?php echo e($item->student->TITLE); ?> <?php echo e($item->student->FRTNAME); ?> <?php echo e($item->student->LSTNAME); ?></td>
                                     <td style="text-align: center"><button wire:click="showedit('<?php echo e($item->MMID); ?>')" type="button" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <div class="text-left font-weight-bold">
                                <p>-ຈໍານວນຊົ່ວໂມງສອນວິຊານີ້ = <?php echo e($this->all_hour); ?> ຊົ່ວໂມງ</p>
                                <p class="text-success">-ຈໍານວນຊົ່ວໂມງທີ່ຂຶ້ນແລ້ວ = <?php echo e(number_format($active_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-danger">-ຈໍານວນຊົ່ວໂມງສອນທີ່ຍັງຕ້ອງໄດ້ຂຶ້ນ = <?php echo e(number_format($this->all_hour - $active_hour)); ?> ຊົ່ວໂມງ</p>
                            </div>
                            <div class="text-right">
                                 <a href="<?php echo e(route('student.subject')); ?>" class="btn btn-success"><i class="fa fa-undo" aria-hidden="true"></i>&nbsp;ກັບຄືນ</a>
                            </div>
                        </div>
                    </div>
                </div>
          </div>
      </div>
      <?php $__env->startPush('scripts'); ?>
      <script>
          $(document).ready(function(){
              $('#date_in').val((new Date().toLocaleString("sv-SE") + '').replace(' ','T'));
              $('#date_out').val((new Date().toLocaleString("sv-SE") + '').replace(' ','T'));
              window.livewire.find('<?php echo e($_instance->id); ?>').set('date_in', (new Date().toLocaleString("sv-SE") + '').replace(' ','T'));
              window.livewire.find('<?php echo e($_instance->id); ?>').set('date_out', (new Date().toLocaleString("sv-SE") + '').replace(' ','T'));
          });
      </script>
      <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/student/save-teacher-up-class-component.blade.php ENDPATH**/ ?>