<div class="container-fluid">
<!-- /.login-logo -->
<div class="card card-outline card-primary">
    <div class="card-body">
        <div class="text-center">
            <img src="<?php echo e(asset('frontend/img/logo.png')); ?>" height="100">
        </div>
        <?php if(Session::has('message')): ?>
           <div class="text-center p-2 text-danger">
               <?php echo e(Session()->get('message')); ?>

           </div>
        <?php endif; ?>
      <form>
        <div class="form-group mb-3">
           <label for="">ຊື່ຜູ້ໃຊ້</label>
           <input type="text"   wire:model="username" placeholder="ຊື່ຜູ້ໃຊ້" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3">
          <label for="">ລະຫັດຜ່ານ</label>
          <input type="password"  id="frm-login-pass"  wire:model="password" placeholder="ລະຫັດຜ່ານ" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="row">
          <div class="col-md-12 p-2">
              <button type="button" wire:click="Login" class="btn btn-primary btn-block"> <i class="fa fa-sign-in-alt"></i>&nbsp;ເຂົ້າລະບົບ</button>
          </div>
        </div>
      </form>
    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
  </div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/auth/login-component.blade.php ENDPATH**/ ?>