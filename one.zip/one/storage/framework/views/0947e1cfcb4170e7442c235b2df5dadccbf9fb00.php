<li class="user-footer">
                <a href="#" wire:click="Logout"><i class="fa fa-sign-in-alt"></i>&nbsp;ອອກລະບົບ</a>
</li><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/auth/logout-component.blade.php ENDPATH**/ ?>