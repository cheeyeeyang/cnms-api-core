
 <!-- Content Wrapper. Contains page content -->
 <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0"></h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <section class="content">
        <div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-lg-2">
              <!-- small box -->
              <div class="small-box bg-success">
                <div class="inner">
                 <h3 style="font-weight:bold"><?php echo e(number_format($count_client)); ?></h3>
                  <p>ລູກຄ້າ</p>
                </div>
                <a href="#" class="small-box-footer"> ລາຍລະອຽດ <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-2">
              <!-- small box -->
              <div class="small-box bg-primary">
                <div class="inner">
                   <h3 style="font-weight:bold"><?php echo e(number_format($count_appointment)); ?></h3>
                  <p>ແຜນນັດພົບລູກຄ້າ</p>
                </div>
                <a href="<?php echo e(route('admin.appointment')); ?>" class="small-box-footer"> ລາຍລະອຽດ <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <div class="col-lg-2">
              <!-- small box -->
              <div class="small-box bg-danger">
                <div class="inner">
                  <h3 style="font-weight:bold"><?php echo e($no_appointment->count()); ?></h3>
                  <p>ຍັງບໍ່ໄດ້ພົບ</p>
                </div>
                <a href="<?php echo e(route('admin.appointment')); ?>" class="small-box-footer"> ລາຍລະອຽດ <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
            <!-- ./col -->
            <div class="col-lg-2">
              <!-- small box -->
              <div class="small-box bg-warning">
                <div class="inner">
                  <h3 style="font-weight:bold"><?php echo e(number_format($count_of_plan)); ?></h3>
                  <p>ນັດພົບລູກຄ້ານອກແຜນ</p>
                </div>
                <a href="<?php echo e(route('admin.appointmentoffplan')); ?>" class="small-box-footer"> ລາຍລະອຽດ <i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <div class="col-lg-2">
              <!-- small box -->
              <div class="small-box bg-info">
                <div class="inner">
                  <h3 style="font-weight:bold">20</h3>
                  <p>ລາຍງານຜົນຕົວຈິງ</p>
                </div>
                <a href="#" class="small-box-footer">ລາຍລະອຽດ<i class="fas fa-arrow-circle-right"></i></a>
              </div>
            </div>
            <!-- ./col -->
          </div>
          <!--row 1-->
        <!--end row1-->
        </div>
  </section>


<?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/dashboard-component.blade.php ENDPATH**/ ?>