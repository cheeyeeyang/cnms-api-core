<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card card-primary card-outline">
            <div class="card-header text-center">
               <h5><b>ລາຍວິຊາທີ່ສອນໃນພາກຮຽນ <?php if($this->semester == 1): ?> I <?php else: ?> II <?php endif; ?> ສົກຮຽນ <?php echo e($this->acyear); ?> ຂອງອາຈານ <?php echo e(auth()->guard('webstaff')->user()->TITEL); ?> <?php echo e(auth()->guard('webstaff')->user()->FNAME); ?> <?php echo e(auth()->guard('webstaff')->user()->LNAME); ?></b></h5>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລໍາດັບ</th>
                    <th>ຊື່ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດຫ້ອງ</th>
                    <th style="text-align: center">ຊ/ມ</th>
                    <th style="text-align: center">ປະເພດຊ/ມ</th>
                    <th>ຫ້ອງ</th>
                    <th>ຈ/ນຊ/ມຂຶ້ນສອນແລ້ວ</th>
                    <th>ຈ/ນຊ/ມຍັງຕ້ອງຂຶ້ນສອນ</th>
                    <th style="text-align: center">ລາຍລະອຽດ</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->where('STTID', 1)->orderBy('memos.MMID', 'desc')->get();
                    $active_hour = 0;
                    foreach($memos as $items){
                        $active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                    }
                    ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e($item->subject->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->subject->CREDIT); ?></td>
                        <td><?php echo e($item->classroom->classroomtype->NAME); ?></td>
                        <td style="text-align: center">
                              <?php if($item->time->TIME =='8:00-9:45'): ?>
                              1
                              <?php elseif($item->time->TIME =='10:00-11:30'): ?>
                              2
                              <?php elseif($item->time->TIME =='13:00-14:45'): ?>
                              3
                              <?php elseif($item->time->TIME =='15:00-16:30'): ?>
                              4
                              <?php endif; ?>
                        </td>
                        <td><?php echo e($item->time->REMARK); ?></td>
                        <td style="text-align: center">
                            <?php if(!empty($item->group->Group)): ?>
                                <?php echo e($item->group->Group); ?>

                            <?php endif; ?>
                        </td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?>/<?php echo e($item->NUMBER_HOUR); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($item->NUMBER_HOUR - $active_hour)); ?>/<?php echo e($item->NUMBER_HOUR); ?></td>
                        <td style="text-align: center"><a href="#" wire:click="ShowDetail('<?php echo e($item->TBID); ?>')"><u>ເບິ່ງລາຍລະອຽດ</u></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <div class="text-left mt-1">
                <?php if($this->status =='true'): ?>
                  <a href="#" wire:click="ReportHourFalse" class="btn btn-danger"><i class="fas fa-times"></i> ສະຫຼຸບຊົ່ວໂມງສອນ</a>
                <?php else: ?>
                  <a href="#" wire:click="ReportHourTrue" class="btn btn-info">ສະຫຼຸບຊົ່ວໂມງສອນ</a>
                <?php endif; ?>
              </div>
                <div class="text-right">
                  <a href="javascript:void(0)" class="btn btn-success" id="btn-print"><i class="fa fa-print" aria-hidden="true"></i>&nbsp;ປຣິ່ນ</a>
              </div>
               <!-- print content -->
                <div class="print-content" style="display:none;" id="page-content">
                 <div class="text-center">
                   <p>ສາທາລະນະລັດ ປະຊາທິປະໄຕ ປະຊາຊົນລາວ</p>
                   <p>ສັນຕິພາບ ເອກະລາດ ປະຊາທິປະໄຕ ເອກະພາບ ວັດທະນະຖາວອນ</p>
                 </div>
                 <div class="text-center">
                       <b><h4>ຕາຕະລາງສະຫຼຸບຊົ່ວໂມງສອນປະຈໍາພາກຮຽນທີ <?php if($this->semester ==1): ?> I <?php else: ?> II <?php endif; ?> ສົກຮຽນ <?php echo e($this->acyear); ?> ຂອງອາຈານ <?php echo e(auth()->guard('webstaff')->user()->TITEL); ?> <?php echo e(auth()->guard('webstaff')->user()->FNAME); ?> <?php echo e(auth()->guard('webstaff')->user()->LNAME); ?></h4></b>
                 </div>
                 <div class="header-content-Print">
                     <div class="left">
                     </div>
                     <div class="right">
                        <h6>ວັນທີ: <?php echo e($this->date_now); ?>

                     </div>
                 </div>
                <table class="report-print-content">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ວັນ,ເດືອນ,ປີຂຶ້ນຫ້ອງ</th>
                    <th>ວິຊາ</th>
                    <th style="text-align: center">ປະເພດ</th>
                    <th style="text-align: center">ຊ/ມ</th>
                    <th style="text-align: center">ປະເພດຊ/ມ</th>
                    <th>ຫ້ອງ</th>
                    <th>ຈ/ນຊ/ມ</th>
                    <th style="text-align: center">ຫ້ອງຮຽນ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                     $active_hour = 0;
                    ?>
                    <?php $__currentLoopData = $reportmemos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $active_hour = round((strtotime($item->DATETIME_OUT) - strtotime($item->DATETIME_IN))/(60*60));
                    ?>
                  <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                        <td><?php echo e($item->SUBJNAME); ?></td>
                        <td><?php echo e($item->CLASSROOMTYPENAME); ?></td>
                        <td style="text-align: center">
                           <?php if($item->TIME =='8:00-9:45'): ?>
                            1
                            <?php elseif($item->TIME =='10:00-11:30'): ?>
                            2
                            <?php elseif($item->TIME =='13:00-14:45'): ?>
                            3
                            <?php elseif($item->TIME =='15:00-16:30'): ?>
                            4
                            <?php endif; ?></td>
                        <td style="text-align: center"><?php echo e($item->REMARK); ?></td>
                        <td style="text-align: center"><?php echo e($item->GRNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e($item->CLASSROOMNAME); ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                          <td  rowspan="<?php echo e($classroomtypes->count() + 1); ?>" colspan="2" style="vertical-align : middle;text-align:center;"><b>ສະຫຼຸບ</b></td>
                          <td rowspan="1" colspan="4" style="vertical-align : middle;text-align:center;"><b>ປະເພດຊົ່ວໂມງ</b></td>
                          <td style="text-align: center"><b>ປົກກະຕິ</b></td>
                          <td style="text-align: center"><b>ເສົາ-ທິດ</b></td>
                          <td style="text-align: center"><b>ລວມ</b></td>
                    </tr>
                    <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php 
                      if(!empty($this->show_semester) && empty($this->start_date) && empty($this->end_date)){
                          $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                          $total_usually_try_active_hour = 0;
                          foreach($usually_try_hour as $usually_item){
                              $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                          }
                          $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                          $total_weekend_try_active_hour = 0;
                          foreach($weekend_try_hour as $weeken_item){
                              $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                          }
                        }elseif(!empty($this->show_semester) && !empty($this->start_date) && !empty($this->end_date)){
                          $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->whereBetween('mm.DATETIME_IN', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                          $total_usually_try_active_hour = 0;
                          foreach($usually_try_hour as $usually_item){
                              $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                          }
                          $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->whereBetween('mm.DATETIME_IN', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                          $total_weekend_try_active_hour = 0;
                          foreach($weekend_try_hour as $weeken_item){
                              $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                          }
                        }else{
                              $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                              $total_usually_try_active_hour = 0;
                              foreach($usually_try_hour as $usually_item){
                                  $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                              }
                              $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                              $total_weekend_try_active_hour = 0;
                              foreach($weekend_try_hour as $weeken_item){
                                  $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                              }
                        }
                     ?>
                    <tr style="text-align: center">
                    <td colspan="4" style="vertical-align : middle;text-align:left;">ຈໍານວນຊ/ມສອນ<?php echo e($item->NAME); ?></td>
                      <td><?php echo e(number_format($total_usually_try_active_hour)); ?></td>
                      <td style="text-align: center"><?php echo e(number_format($total_weekend_try_active_hour)); ?></td>
                      <td><b><u><?php echo e(number_format( $total_usually_try_active_hour + $total_weekend_try_active_hour)); ?></u></b></td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <div class="text-right" style="padding:10px;margin-right:2.4cm;font-size:14pt;">
                     <p><b>ອາຈານ</b></p>
                </div>
              </div>
                <?php $__env->startPush('scripts'); ?>
                    <script>
                        //print sale
                                  $('#btn-print').click(function() {
                                        var printContents = $(".print-content").html();
                                        var originalContents = document.body.innerHTML;
                                        document.body.innerHTML = printContents;
                                        window.print();
                                        document.body.innerHTML = originalContents;
                                        location.reload();
                                });
                                $('#ExportToExcel').click(function(){
                                      let file = new Blob([$('#page-content').html()], { type: "application/vnd.ms-excel" });
                                      let url = URL.createObjectURL(file);
                                      let a = $("<a />", {
                                          href: url,
                                          download: "filename.xls"
                                      }).appendTo("div").get(0).click();
                                      e.preventDefault();
                                 });
                  </script>
                <?php $__env->stopPush(); ?>  
                  <!-- end print content   -->
              <?php if($this->status =='true'): ?>
              <div class="row">
                     <div class="col-md-4">
                        <div class="form-group">
                          <label for="">ເລືອກພາກຮຽນ</label>
                          <select class="form-control" wire:model="show_semester">
                                  <option value="1">ພາກຮຽນ I</option>
                                  <option value="2">ພາກຮຽໜ II</option>
                            </select>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                          <label for=""> ເວລາເລີ່ມຕົ້ນ</label>
                          <input type="date" class="form-control" wire:model="start_date">
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                          <label for=""> ເວລາສິ້ນສຸດ</label>
                          <input type="date" class="form-control" wire:model="end_date">
                        </div>
                     </div>
              </div>
              <div class="text-center">
                 <p><b>ຕາຕະລາງສະຫຼຸບຊົ່ວໂມງສອນປະຈໍາພາກຮຽນທີ <?php if($this->semester ==1): ?> I <?php else: ?> II <?php endif; ?> ສົກຮຽນ <?php echo e($this->acyear); ?> ຂອງອາຈານ <?php echo e(auth()->guard('webstaff')->user()->TITEL); ?> <?php echo e(auth()->guard('webstaff')->user()->FNAME); ?> <?php echo e(auth()->guard('webstaff')->user()->LNAME); ?></b></p>
              </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th>ວັນ,ເດືອນ,ປີຂຶ້ນຫ້ອງ</th>
                    <th>ວິຊາ</th>
                    <th style="text-align: center">ປະເພດ</th>
                    <th style="text-align: center">ຊ/ມ</th>
                    <th style="text-align: center">ປະເພດຊ/ມ</th>
                    <th>ຫ້ອງ</th>
                    <th>ຈ/ນຊ/ມ</th>
                    <th style="text-align: center">ຫ້ອງຮຽນ</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php 
                     $i = 1;
                     $active_hour = 0;
                    ?>
                    <?php $__currentLoopData = $reportmemos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $active_hour = round((strtotime($item->DATETIME_OUT) - strtotime($item->DATETIME_IN))/(60*60));
                    ?>
                  <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                        <td><?php echo e($item->SUBJNAME); ?></td>
                        <td><?php echo e($item->CLASSROOMTYPENAME); ?></td>
                        <td style="text-align: center">
                           <?php if($item->TIME =='8:00-9:45'): ?>
                            1
                            <?php elseif($item->TIME =='10:00-11:30'): ?>
                            2
                            <?php elseif($item->TIME =='13:00-14:45'): ?>
                            3
                            <?php elseif($item->TIME =='15:00-16:30'): ?>
                            4
                            <?php endif; ?></td>
                        <td style="text-align: center"><?php echo e($item->REMARK); ?></td>
                        <td style="text-align: center"><?php echo e($item->GRNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?></td>
                        <td style="text-align: center"><?php echo e($item->CLASSROOMNAME); ?></td>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                          <td  rowspan="<?php echo e($classroomtypes->count() + 1); ?>" colspan="2" style="vertical-align : middle;text-align:center;"><b>ສະຫຼຸບ</b></td>
                          <td rowspan="1" colspan="4" style="vertical-align : middle;text-align:center;"><b>ປະເພດຊົ່ວໂມງ</b></td>
                          <td style="text-align: center"><b>ປົກກະຕິ</b></td>
                          <td style="text-align: center"><b>ເສົາ-ທິດ</b></td>
                          <td style="text-align: center"><b>ລວມ</b></td>
                    </tr>
                    <?php $__currentLoopData = $classroomtypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php 
                      if(!empty($this->show_semester) && empty($this->start_date) && empty($this->end_date)){
                          $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                          $total_usually_try_active_hour = 0;
                          foreach($usually_try_hour as $usually_item){
                              $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                          }
                          $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                          $total_weekend_try_active_hour = 0;
                          foreach($weekend_try_hour as $weeken_item){
                              $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                          }
                        }elseif(!empty($this->show_semester) && !empty($this->start_date) && !empty($this->end_date)){
                          $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->whereBetween('mm.DATETIME_IN', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                          $total_usually_try_active_hour = 0;
                          foreach($usually_try_hour as $usually_item){
                              $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                          }
                          $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('tt.SEMESTER', $this->show_semester)->whereBetween('mm.DATETIME_IN', [$this->start_date, date('Y-m-d H:i:s', strtotime($this->end_date . ' +1 day'))])->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                          $total_weekend_try_active_hour = 0;
                          foreach($weekend_try_hour as $weeken_item){
                              $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                          }
                        }else{
                              $usually_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ປົກກະຕິ')->get();
                              $total_usually_try_active_hour = 0;
                              foreach($usually_try_hour as $usually_item){
                                  $total_usually_try_active_hour += round((strtotime($usually_item->DATETIME_OUT) - strtotime($usually_item->DATETIME_IN))/(60*60));
                              }
                              $weekend_try_hour = DB::table('memos as mm')->join('timetables as tt','tt.TBID', '=', 'mm.TBID')->join('classrooms as cr','cr.CRID','=','tt.CRID')->join('classroomtypes as crt','crt.CRTID','=','cr.CRTID')->join('staff as sf', 'sf.STID', '=', 'tt.STID')->where('mm.STTID', 1)->where('sf.STID', auth()->guard('webstaff')->user()->STID)->where('crt.CRTID', $item->CRTID)->join('times as t','t.TID','=','tt.TID')->where('t.REMARK', 'ເສົາ-ທິດ')->get();
                              $total_weekend_try_active_hour = 0;
                              foreach($weekend_try_hour as $weeken_item){
                                  $total_weekend_try_active_hour += round((strtotime($weeken_item->DATETIME_OUT) - strtotime($weeken_item->DATETIME_IN))/(60*60));
                              }
                        }
                     ?>
                    <tr style="text-align: center">
                    <td colspan="4" style="vertical-align : middle;text-align:left;">ຈໍານວນຊ/ມສອນ<?php echo e($item->NAME); ?></td>
                      <td><?php echo e(number_format($total_usually_try_active_hour)); ?></td>
                      <td style="text-align: center"><?php echo e(number_format($total_weekend_try_active_hour)); ?></td>
                      <td><b><u><?php echo e(number_format( $total_usually_try_active_hour + $total_weekend_try_active_hour)); ?></u></b></td>
                    </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <!-- show details  -->
        <div wire:ignore.self class="modal fade" id="modal-show-detail">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
              <div class="text-center"><h5><b>ຂໍ້ມູນການຂຶ້ນຫ້ອງສອນຂອງອາຈານ <?php echo e($this->teacher); ?> ວິຊາ <?php echo e($this->subject); ?> (<?php echo e($this->classroomtype); ?>)</b></h5></div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ລໍາດັບ</th>
                                <th>ວັນ,ເດືອນ,ປີ ຂຶ້ນຫ້ອງ</th>
                                <th>ເວລາຂຶ້ນຫ້ອງ</th>
                                <th style="text-align: center">ເວລາລົງຫ້ອງ</th>
                                <th style="text-align: center">ສະຖານະ</th>
                                <th>ເຫດຜົນ</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php 
                               $i = 1;
                              ?>
                              <?php $__currentLoopData = $this->memos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                   <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->DATETIME_IN))); ?></td>
                                    <td><?php echo e(date('H:i:s A', strtotime($item->DATETIME_IN))); ?></td>
                                    <td style="text-align: center"><?php echo e(date('H:i:s A', strtotime($item->DATETIME_OUT))); ?></td>
                                    <td style="text-align: center"><?php echo e($item->status->NAME); ?></td>
                                    <td><?php echo e($item->SEASON_MORE); ?></td>
                             </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            </table>
                            <div class="text-left font-weight-bold">
                            <p>-ຈໍານວນຊົ່ວໂມງສອນວິຊານີ້ = <?php echo e(number_format($this->all_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-success">-ຈໍານວນຊົ່ວໂມງທີ່ຂຶ້ນແລ້ວ = <?php echo e(number_format($this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                                <p class="text-danger">-ຈໍານວນຊົ່ວໂມງສອນທີ່ຍັງຕ້ອງໄດ້ຂຶ້ນ = <?php echo e(number_format($this->all_hour - $this->show_active_hour)); ?> ຊົ່ວໂມງ</p>
                            </div>
                        </div>
              </div>
            </div>
          </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/teacher/subject-list-component.blade.php ENDPATH**/ ?>