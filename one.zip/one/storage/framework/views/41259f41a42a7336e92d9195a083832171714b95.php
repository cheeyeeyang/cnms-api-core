<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><b>ຂໍ້ມູນການປະເມີນວິຊາ:<?php echo e($this->subject); ?> <?php if($this->semester ==1): ?>I <?php else: ?> II <?php endif; ?></span> ສົກສຶກສາ <?php echo e($this->acyear); ?></span> </b></h5>
            </div>
            <div class="card-body">
                <div class="row">
                        <div class="col-md-3 p-1">
                            <input wire:model="search" type="text" class="form-control" placeholder="ຄົ້ນຫາ">
                        </div>
                </div>
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລ/ດ</th>
                    <th  style="text-align: center">ລະຫັດນັກສຶກສາ</th>
                    <th  style="text-align: center">ເພດ</th>
                    <th>ຊື່</th>
                    <th>ນາມສະກຸນ</th>
                    <th>ເບີໂທ</th>
                    <th style="text-align: center">ຄະແນນລວມ</th>
                    <th style="text-align: center">ລາຍລະອຽດ</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php 
                     use Carbon\Carbon;
                     $i = 1;
                     $count_absent = 0;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                      $score = DB::table('evaluations')->where('TBID', $this->TBID)->where('STDID', $item->STDID)->sum('SCORE');
                    ?>
                    <?php if($score > 0): ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                        <td style="text-align: center"><?php echo e($item->STDID); ?></td>
                        <td style="text-align: center">
                            <?php echo e($item->TITLE); ?>

                        </td>
                        <td>
                           <?php echo e($item->FRTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->LSTNAME); ?>

                        </td>
                        <td>
                           <?php echo e($item->PHONE); ?>

                        </td>
                        <td style="text-align: center"><?php echo e($score); ?></td>
                        <td style="text-align: center">  <a href="#" wire:click="ShowDetail('<?php echo e($item->STDID); ?>')"><u>ລາຍລະອຽດ</u></a></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div> 
            </div>
          </div>
        </div>
      </div>
       <!-- show details  -->
       <div wire:ignore.self class="modal fade" id="modal-show-detail">
          <div class="modal-dialog modal-xl">
            <div class="modal-content">
              <div class="modal-header">
              <h6 class="modal-title"><b>ຂໍ້ມູນລາຍລະອຽດການປະເມີນ</b></h6>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                 <p class="text-left">
                     ລະຫັດນັກສຶກສາ: <b> <?php echo e($this->student_id); ?></b>  <br>
                     ຊື່ ແລະ ນາມສະກຸນ: <b><?php echo e($this->fullname); ?></b>
                 </p>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                            <thead>
                            <tr>
                                <th style="text-align: center">ວັນທີ</th>
                                <th style="text-align: center">ລ/ດ</th>
                                <th>ຄໍາຖາມ</th>
                                <th style="text-align: center">ຄະແນນ</th>
                            </tr>
                            </thead>
                            <tbody>
                              <?php 
                               $i = 1;
                              ?>
                              <?php $__currentLoopData = $this->detailevaluation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                                    <td style="text-align: center"><?php echo e($i++); ?></td>
                                    <td>
                                         <?php if(!empty($item->question->QUESTION)): ?>
                                                <?php echo e($item->question->QUESTION); ?>

                                         <?php endif; ?>
                                    </td>
                                    <td style="text-align: center"><?php echo e($item->SCORE); ?></td>
                                </tr>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <tr>
                                 <td colspan="3"><b>ສະຫຼຸບ</b></td>
                                 <td style="text-align: center"><b><u><?php echo e($show_score); ?></u></b></td>
                             </tr>
                            </tbody>
                            </table>
                            <div class="text-left">
                                      <?php if(!empty($this->evaluation_comment)): ?>
                                         <p><b>ຂໍ້ສະເໜີ</b>: <?php echo e($this->evaluation_comment); ?></p>
                                      <?php endif; ?>
                            </div>
                        </div>
              </div>
            </div>
          </div>
        </div>
        <?php $__env->startPush('scripts'); ?>
        <script>
          //show details
          window.addEventListener('show-modal-show-detail', event => {
            $('#modal-show-detail').modal('show');
          })
        </script>
      <?php $__env->stopPush(); ?>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/teacher/detail-evaluation-component.blade.php ENDPATH**/ ?>