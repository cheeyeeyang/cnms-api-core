<div>
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">ຈັດການຂໍ້ມູນພະນັກງານ</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                        <li class="breadcrumb-item active">ຂໍ້ມູນພະນັກງານ</li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <!--customers -->
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <form>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span>ເພດ</label>
                                        <select class="form-control <?php $__errorArgs = ['TITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            wire:model="TITLE">
                                            <option value="ທ້າວ">ທ້າວ</option>
                                            <option value="ນາງ">ນາງ</option>
                                        </select>
                                        <?php $__errorArgs = ['TITLE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ຊື່</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['FNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="ຊື່" wire:model="FNAME">
                                        <?php $__errorArgs = ['FNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ນາມສະກຸນ</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['LNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="ນາມສະກຸນ" wire:model="LNAME">
                                        <?php $__errorArgs = ['LNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ເບີໂທ</label>
                                        <input type="number" class="form-control <?php $__errorArgs = ['PHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>)"
                                            placeholder="ເບີໂທ" wire:model="PHONE">
                                        <?php $__errorArgs = ['PHONE'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ອີເມວ</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['EMAIL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="example@gmail.com" wire:model="EMAIL">
                                        <?php $__errorArgs = ['EMAIL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span>ສິດ</label>
                                        <select class="form-control <?php $__errorArgs = ['RID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            wire:model="RID">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->RID); ?>"><?php echo e($item->ROLE); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['RID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ຊື່ຜູ້ໃຊ້</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['USERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="ຊື່ຜູ້ໃຊ້" wire:model="USERNAME">
                                        <?php $__errorArgs = ['USERNAME'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for=""><span style="color:red;">*</span> ລະຫັດຜ່ານ</label>
                                        <input type="password" class="form-control" placeholder="ລະຫັດຜ່ານ"
                                            wire:model="password">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <?php if(!empty($this->hiddenId)): ?>
                            <button type="button" wire:click="store" class="btn btn-primary btn-block"><i
                                    class="fas fa-pen"></i>&nbsp;ແກ້ໄຂ</button>
                            <?php else: ?>
                            <button type="button" wire:click="store" class="btn btn-success btn-block"><i
                                    class="fas fa-download"></i>&nbsp;ບັນທຶກ</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input type="text" class="form-control" wire:model="search"
                                        placeholder="ຄົ້ນຫາ ...">
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive mt-2">
                            <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                <thead>
                                    <tr>
                                        <th style="text-align: center">ລ/ດ</th>
                                        <th style="text-align: center">ເພດ</th>
                                        <th>ຊື່</th>
                                        <th>ນາມສະກຸນ</th>
                                        <th style="text-align: center">ເບີໂທ</th>
                                        <th style="text-align: center">ຊື່ຜູ້ໃຊ້</th>
                                        <th>ອີເມວ</th>
                                        <th>ສິດ</th>
                                        <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo e($i++); ?></td>
                                        <td style="text-align: center">
                                            <?php echo e($item->TITLE); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->FNAME); ?>

                                        </td>
                                        <td><?php echo e($item->LNAME); ?></td>
                                        <td style="text-align:center">
                                            <?php echo e($item->PHONE); ?>

                                        </td>
                                        <td style="text-align:center">
                                            <?php echo e($item->USERNAME); ?>

                                        </td>
                                        <td><?php echo e($item->EMAIL); ?></td>
                                        <td>
                                            <?php if(!empty($item->role->ROLE)): ?>
                                            <?php echo e($item->role->ROLE); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="#" class="btn btn-warning btn-sm"
                                                wire:click="edit('<?php echo e($item->EMPID); ?>')"><i class="fa fa-edit"></i></a>
                                            <a href="#" class="btn btn-danger btn-sm"
                                                wire:click="showDestroy('<?php echo e($item->EMPID); ?>')"><i
                                                    class="fa fa-times"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="row justify-content-center">
                                <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- /.modal-delete -->
        <div class="modal fade" id="modal-delete">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">ທ່ານຕ້ອງການລຶບຂໍ້ມນີ້ບໍ ?</h3>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" wire:model="hiddenId">
                        <h4>ຊື່: <?php echo e($this->FNAME); ?></h4>
                        <h4>ນາມສະກຸນ: <?php echo e($item->LNAME); ?></h4>
                        <h4>ເບີໂທ: <?php echo e($item->PHONE); ?></h4>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-warning" data-dismiss="modal"><i
                                class="fas fa-undo-alt"></i> ຍົກເລີກ</button>
                        <button type="button" class="btn btn-danger" wire:click="destroy"><i class="fas fa-times"></i>
                            ລຶບ</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <script>
    $(document).ready(function() {
        $('#selectsubject').select2();
        $('#selectsubject').on('change', function(e) {
            var data = $('#selectsubject').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('selectsubject', data);
        });
        $('#selectdepartment').select2();
        $('#selectdepartment').on('change', function(e) {
            var data = $('#selectdepartment').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('DEPTID', data);
        });
        $('#selectacyear').select2();
        $('#selectacyear').on('change', function(e) {
            var data = $('#selectacyear').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('ACYEAR', data);
        });
        $('#selecttime').select2();
        $('#selecttime').on('change', function(e) {
            var data = $('#selecttime').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('time_id', data);
        });
        $('#selectteacher').select2();
        $('#selectteacher').on('change', function(e) {
            var data = $('#selectteacher').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('selectteacher', data);
        });
        $('#selectclassroom').select2();
        $('#selectclassroom').on('change', function(e) {
            var data = $('#selectclassroom').select2("val");
            window.livewire.find('<?php echo e($_instance->id); ?>').set('selectclassroom', data);
        });
    });
    window.addEventListener('show-modal-delete', event => {
        $('#modal-delete').modal('show');
    })
    window.addEventListener('hide-modal-delete', event => {
        $('#modal-delete').modal('hide');
    })
    </script>
    <?php $__env->stopPush(); ?>
</div><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/setting/employee-component.blade.php ENDPATH**/ ?>