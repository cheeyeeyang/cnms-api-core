<div>
    <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>ຈັດການຂໍ້ມູນເປີດການປະເມີນ</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                <li class="breadcrumb-item active">ຂໍ້ມູນເປີດການປະເມີນ</li>
              </ol>
            </div>
          </div>
        </div>
      </section>
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <!--Foram add new-->
            <div class="col-md-4">
              <div class="card card-outline card-primary">
                <form>
                    <div class="card-body">
                        <input type="hidden" wire:model="hiddenId" value="<?php echo e($hiddenId); ?>">
                        <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label><span style="color:red;">*</span> ເລືອກສະຖານະ</label>
                                <select wire:model="status"  class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">ເລືອກ</option>
                                    <option value="1">ເປີດ</option>
                                    <option value="0">ປິດ</option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label><span style="color:red;">*</span>ວັນທີກໍາໜົດ</label>
                                <input type="date" wire:model="expiry_date"  class="form-control <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['expiry_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between md-2">
                            <button type="button" wire:click="resetField" class="btn btn-primary"><i class="fas fa-undo-alt"></i>&nbsp;Reset</button>
                            <button type="button" wire:click="store" class="btn btn-success"><i class="fas fa-download"></i>&nbsp;ບັນທຶກ</button>
                        </div>
                    </div>
                </form>
              </div>
            </div>
            <!--List users- table table-bordered table-striped -->
            <div class="col-md-8">
              <div class="card card-outline card-primary">
                <div class="card-header">
                  <div class="row">
                    <div class="col-md-6">
                      <label>ຂໍ້ມູນເປີດການປະເມີນ</label>
                    </div>
                    <div class="col-md-6">
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                      <thead>
                        <tr>
                          <th style="text-align:center">ລໍາດັບ</th>
                          <th>ວັນທີກໍາໜົດ</th>
                          <th>ສະຖານະ</th>
                          <th style="text-align:center">ປຸ່ມຄໍາສັ່ງ</th>
                        </tr>
                        </thead>
                        <tbody>
                          <?php
                          $i=1;
                          ?>
                          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td style="text-align:center;"><?php echo e($i++); ?></td>
                              <td><?php echo e(date('d-m-Y', strtotime($item->expiry_date))); ?></td>
                              <td>
                                <?php if($item->status ==1): ?> 
                                   ເປີດ
                                <?php else: ?>
                                  ປິດ
                                <?php endif; ?>
                              </td>
                              <td style="text-align:center">
                                  <button wire:click="edit('<?php echo e($item->id); ?>')" type="button" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                  <button wire:click="showDestroy('<?php echo e($item->id); ?>')" type="button" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                              </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                      <div>
                    </div>      
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

       <!-- /.modal-delete -->
       <div class="modal fade" id="modal-delete">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h3 class="modal-title">ທ່ານຕ້ອງການລຶບຂໍ້ມນີ້ບໍ ?</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" wire:model="hiddenId">
                  <h4>ສະຖານະ: <?php echo e($this->status); ?></h4>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-warning" data-dismiss="modal"><i class="fas fa-undo-alt"></i> ຍົກເລີກ</button>
              <button wire:click="destroy(<?php echo e($hiddenId); ?>)" type="button" class="btn btn-danger"><i class="fas fa-times"></i> ລຶບ</button>
            </div>
          </div>
        </div>
      </div>
</div>
<?php $__env->startPush('scripts'); ?>
    <script>
      window.addEventListener('show-modal-delete', event => {
          $('#modal-delete').modal('show');
      })
      window.addEventListener('hide-modal-delete', event => {
          $('#modal-delete').modal('hide');
      })
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/backend/technical/setting/open-evaluation-component.blade.php ENDPATH**/ ?>