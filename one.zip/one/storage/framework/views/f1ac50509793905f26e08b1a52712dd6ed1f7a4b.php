<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ລະບົບຈັດການການຂຶ້້ນຫ້ອງສອນຂອງຄະນະວິທະຍາສາດທໍາມະຊາດ</title>
  <link rel="icon" type="image/png" href="<?php echo e(asset('frontend/img/logo.png')); ?>"/>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/fontawesome-free/css/all.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/summernote-bs4.min.css')); ?>">
  <!-- Toastr -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/toastr/toastr.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/login.css')); ?>">
  <!-- flag-icon-css -->
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/adminlte.min.css')); ?>">
  <link href="<?php echo e(asset('css/sidebars.css')); ?>" rel="stylesheet">
  <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/tempusdominus-bootstrap-4.min.css')); ?>">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.min.css')); ?>">
  <!-- JQVMap -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/OverlayScrollbars.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/adminlte.min.css')); ?>">
  <!-- overlayScrollbars -->
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/daterangepicker.css')); ?>">
  <!-- summernote -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote-bs4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/buttons.bootstrap4.min.css')); ?>">
 <style>
  .header-content-Print{
    width: 95%;
    margin-left:auto;
    margin-right:auto;
    display:flex;
    justify-content:center;
    margin-bottom:5px;
  }
  .header-content-Print .left{
    width:50%;
    text-align:left;
  }
  .header-content-Print .right{
    width:50%;
    text-align:right;
  }
  .report-print-content{
  width: 95%;
  margin-left:auto;
  margin-right:auto;
 }
 .report-print-content, .report-print-content th,.report-print-content tr, .report-print-content td{
  border-collapse: collapse;
  border: 0.5px solid #000;
 }
  .head-logo-title{
    display: flex;
    justify-content: space-between;
    padding-left: 10px;
    padding-right: 10px;
    width: 100%;
}
.bill-header-logo{
    display: flex;
    flex-direction: column;
    text-align: left;
    width: 30%;
}
.bill-header-title{
    width: 30%;
    text-align: center;
    display: flex;
    justify-content: center;
    flex-direction: column;
}
.bill-signature{
    display: flex;
    justify-content: space-between;
    text-align: center;
    align-items: center;
    padding-left: 30px;
    padding-right: 30px;
    padding-bottom: 80px;
}
.signature-left, .signature-right{
    display: flex;
    justify-content: center;
    text-align: center;
    align-items: center;
}
.print-content{
  background-color:#FFF;
  width:200px;
  height:auto;
  padding:10px;
  font-size:8pt;
  font-family:'Saysettha OT';
}
.order-detail-bill-right{
  white-space:nowrap;
}
 </style>
  <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body class="hold-transition layout-top-nav">
 <div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand-md navbar-light navbar-white">
    <div class="container-fluid">
      <a href="<?php echo e(route('student.subject')); ?>" class="navbar-brand">
      <img src="<?php echo e(asset('frontend/img/logo.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">FNS</span>
      </a>
      <div class="collapse navbar-collapse order-3" id="navbarCollapse">
      <ul class="navbar-nav">
          <!--Modules-->
           <li class="nav-item">
            <a href="<?php echo e(route('teacher.subject')); ?>"  class="nav-link"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;ຕິດຕາມການຂຶ້ນຫ້ອງສອນອາຈານ</a>
          </li>
          <!-- end 2 -->
          <li class="nav-item">
                  <a  href="<?php echo e(route('teacher.student')); ?>" class="nav-link"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;ຕິດຕາມການຂຶ້ນຫ້ອງນັກສຶກສາ</a>
          </li> <!-- end li 1 -->
          <!-- end Reserve modules 2 -->
          <li class="nav-item">
            <a  href="<?php echo e(route('teacher.evaluation')); ?>" class="nav-link"><i class="fa fa-calendar-check" aria-hidden="true"></i>&nbsp;ຕິດຕາມການປະເມີນ</a>
          </li> <!-- end 3 -->
        </ul>
      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      </div>
      <!-- Right navbar links -->
      <!-- Right navbar links -->
      <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
        <!--Logout-->
        <li class="nav-item dropdown user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
              <?php if(!empty(auth()->guard('webstaff')->user()->IMAGE)): ?>
              <img src="<?php echo e(asset(auth()->guard('webstaff')->user()->IMAGE)); ?>" class="user-image img-circle elevation-2" alt="User Image">
              <?php else: ?>
              <img src="<?php echo e(asset('frontend/img/user.png')); ?>" class="user-image img-circle elevation-2" alt="User Image">
              <?php endif; ?>
          </a>
          <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
            <!-- User image -->
            <li class="user-header bg-primary">
               <?php if(!empty(auth()->guard('webstaff')->user()->IMAGE)): ?>
              <img src="<?php echo e(asset(auth()->guard('webstaff')->user()->IMAGE)); ?>" class="img-circle elevation-2" alt="User Image">
              <?php else: ?>
              <img src="<?php echo e(asset('frontend/img/user.png')); ?>" class="img-circle elevation-2" alt="User Image">
              <?php endif; ?>
                <p><?php echo e(auth()->guard('webstaff')->user()->TITEL); ?> <?php echo e(auth()->guard('webstaff')->user()->FNAME); ?> <?php echo e(auth()->guard('webstaff')->user()->LNAME); ?></p>
            </li>
            <!-- Menu Footer-->
           <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.auth.logout-teacher-component', [])->html();
} elseif ($_instance->childHasBeenRendered('9dt49pk')) {
    $componentId = $_instance->getRenderedChildComponentId('9dt49pk');
    $componentTag = $_instance->getRenderedChildComponentTagName('9dt49pk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9dt49pk');
} else {
    $response = \Livewire\Livewire::mount('frontend.auth.logout-teacher-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('9dt49pk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
          </ul>
        </li>
      </ul>
      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    </div>
  </nav>
    <!-- /.navbar -->
      <div class="content-wrapper">
            <?php echo e($slot); ?>

      </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>ເລີ່ມວັນທີ:05/09/2022 <a href="https://www.facebook.com/FNS.NUOL.edu.la/">ຄະນະວິທະຍາສາດທໍາມະຊາດ</a></strong>
    <div class="float-right d-none d-sm-inline-block">
    <b>&copy;Phonepanya Dev&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Version</b>1.1.0
    </div>
  </footer>
  </div>
  <!-- ./wrapper -->
  <!-- jQuery -->
  <script src="<?php echo e(asset('assets/jquery/jquery.min.js')); ?>"></script>
  <!-- jQuery UI 1.11.4 -->
  <script>
    $.widget.bridge('uibutton', $.ui.button)
  </script>
  <!-- Bootstrap 4 -->
  <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
  <!-- ChartJS -->
  <script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
  <!-- Sparkline -->
  <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
  <!-- JQVMap -->
  <script src="<?php echo e(asset('assets/js/adminlte.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/dashboard.js')); ?>"></script>
  <!-- jQuery Knob Chart -->
  <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>
  <!-- daterangepicker -->
  <script src="<?php echo e(asset('assets/js/jquery.overlayScrollbars.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
  <!-- Tempusdominus Bootstrap 4 -->
  <script src="<?php echo e(asset('assets/js/daterangepicker.js')); ?>"></script>
  <!-- Summernote -->
  <script src="<?php echo e(asset('assets/js/summernote-bs4.min.js')); ?>"></script>
  <!-- overlayScrollbars -->
  <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
   <!-- DataTables  & Plugins -->
   <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/28.0.0/classic/ckeditor.js"></script>
    <script src="<?php echo e(asset('admin/plugins/toastr/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
  <?php echo \Livewire\Livewire::scripts(); ?>

  <script>
  function labelFormatter(label, series) {
    return '<div style="font-size:13px; text-align:center; padding:2px; color: #fff; font-weight: 600;">'
      + label
      + '<br>'
      + Math.round(series.percent) + '%</div>'
  }
</script>
<script>
  $(function () {
    // Summernote
    $('#summernote').summernote()
    $('.select2').select2()
    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["excel", "print"]
      //"buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<script>
  window.livewire.on('alert', param => {
        toastr[param['type']](param['message'],param['type']);
  });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
  <!-- AdminLTE App -->
</body>
</html><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/layouts/teacher.blade.php ENDPATH**/ ?>