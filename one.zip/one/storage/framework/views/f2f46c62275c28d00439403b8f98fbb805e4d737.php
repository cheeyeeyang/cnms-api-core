<div>
    <div>
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">ລູກຄ້າທີ່ບໍ່ມັກຊື້ສິນຄ້າ</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">ໜ້າຫຼັກ</a></li>
                            <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.appointment')); ?>">ຈັດການຂໍ້ມູນແຜນນັດໝາຍ</li></a>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <!--customers -->
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                                <div class="row">
                                     <div class="col-md-9">
                                          <h4 class="text-danger"> <i class="fas fa-users"></i>ລູກຄ້າທີ່ບໍ່ມັກຊື້ສິນຄ້າ</h4>
                                     </div>
                                     <div class="col-md-3">
                                           <div class="form-group">
                                              <label for="">ຄົ້ນຫາ</label>
                                              <input type="text" class="form-control" placeholder="ລູກຄ້າ ຫຼື ເບີໂທ ..." wire:model="search">
                                           </div>
                                     </div>
                                </div>
                            <div class="table-responsive mt-2">
                                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center">ລ/ດ</th>
                                            <th>ລູກຄ້າ</th>
                                            <th>ເບີໂທ</th>
                                            <th style="text-align: center">ປະເພດ</th>
                                            <th style="text-align: center">ເກຣດ</th>
                                            <th style="text-align: center">ສິນຄ້າທີ່ເຄີຍຊື້</th>
                                            <th style="text-align: center">ບ້ານ</th>
                                            <th style="text-align: center">ເມືອງ</th>
                                            <th style="text-align: center">ແຂວງ</th>
                                            <th style="text-align: center">ປຸ່ມຄໍາສັ່ງ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $i = 1;
                                        ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                            <td style="text-align: center"><?php echo e($i++); ?></td>
                                            <td>
                                                <?php echo e($item->client_name); ?>	
                                            </td>
                                            <td>
                                               <?php echo e($item->client_phone); ?>

                                            </td>
                                            <td style="text-align: center"><?php echo e($item->client_type); ?></td>
                                            <td style="text-align: center"><?php echo e($item->client_grade); ?></td>
                                            <td style="text-align: center"><?php echo e(number_format($item->sum_qty)); ?></td>
                                            <td><?php echo e($item->client_village); ?></td>
                                            <td><?php echo e($item->client_district); ?></td>
                                            <td><?php echo e($item->client_province); ?></td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('admin.detailaddappappointment', ['slug' => $item->client_id])); ?>" class="text-primary"><u>ເລືອກ</u></a>
                                            </td>
                                        </tr>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="row justify-content-center">
                                  <?php echo e($data->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\cnms\resources\views/livewire/backend/setting/detail-appointment-component.blade.php ENDPATH**/ ?>