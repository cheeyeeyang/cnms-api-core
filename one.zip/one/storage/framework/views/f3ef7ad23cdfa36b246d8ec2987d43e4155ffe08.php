<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item active"></li>
          </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5>ສາຍວິຊາຮຽນໃນພາກຮຽນທີ <?php if($this->semester ==1): ?> I <?php else: ?> II <?php endif; ?> ຂອງຫ້ອງ <?php echo e(auth()->guard('webstudent')->user()->group->Group); ?> ສົກຮຽນ <?php echo e(auth()->guard('webstudent')->user()->acyear->ACNAME); ?></h5>
            </div>
            <div class="card-body">
              <div class="table-responsive mt-2">
                <table class="table table-bordered table-striped" style="white-space:nowrap;">
                  <thead>
                  <tr>
                    <th style="text-align: center">ລໍາດັບ</th>
                    <?php if(!empty($openelaluation->status) && $openelaluation->status ==1): ?>
                    <th style="text-align: center">ເລືອກ</th>
                    <?php endif; ?>
                    <th>ວິຊາ</th>
                    <th style="text-align: center">ໜ່ວຍກິດ</th>
                    <th>ປະເພດ</th>
                    <th style="text-align: center">ຊົ່ວໂມງ</th>
                    <th style="text-align: center">ພາກ</th>
                    <th>ຫ້ອງຮຽນ</th>
                    <th>ຊື່ ແລະ ນາມສະກຸນອາຈານ</th>
                    <th>ຊ/ມຂຶ້ນສອນແລ້ວ</th>
                    <th>ຊ/ມຍັງຄ້າງຂຶ້ນສອນ</th>
                    <?php if(auth()->guard('webstudent')->user()->role_id !=0): ?>
                    <th style="text-align: center">ຈັດການ</th>
                    <?php endif; ?>
                  </tr>
                  </thead>
                  <tbody>
                    <?php
                     $i = 1;
                    ?>
                    <?php $__currentLoopData = $timetables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $memos = DB::table('memos')->where('TBID', $item->TBID)->where('STTID', 1)->orderBy('memos.MMID', 'desc')->get();
                    $active_hour = 0;
                    foreach($memos as $items){
                        $active_hour += round((strtotime($items->DATETIME_OUT) - strtotime($items->DATETIME_IN))/(60*60));
                    }
                    $check_evaluation_already = DB::table('evaluations')->where('TBID', $item->TBID)->where('STDID', auth()->guard('webstudent')->user()->STDUSER)->where('ACYEAR', auth()->guard('webstudent')->user()->acyear->ACNAME)->where('STATUS', 1)->get();
                    ?>
                    <tr>
                        <td style="text-align: center"><?php echo e($i++); ?></td>
                         <?php if(!empty($openelaluation->status) && $openelaluation->status ==1): ?>
                              <?php if($check_evaluation_already->count() > 0): ?>
                              <td style="text-align: center"><a href="<?php echo e(route('student.evaluation', ['slug' => $item->TBID])); ?>" class="text-success"><u>ປະເມີນແລ້ວ</u></a></td>
                              <?php else: ?>
                                <td style="text-align: center"><a href="<?php echo e(route('student.evaluation', ['slug' => $item->TBID])); ?>" class="text-danger"><u>ປະເມີນ</u></a></td>
                              <?php endif; ?>
                          <?php endif; ?>
                        <td><?php echo e($item->subject->SUBJNAME); ?></td>
                        <td style="text-align: center"><?php echo e($item->subject->CREDIT); ?></td>
                        <td><?php echo e($item->classroom->classroomtype->NAME); ?></td>
                        <td style="text-align: center">
                            <?php if($item->time->TIME =='8:00-9:45'): ?>
                            1
                            <?php elseif($item->time->TIME =='10:00-11:30'): ?>
                            2
                            <?php elseif($item->time->TIME =='13:00-14:45'): ?>
                            3
                            <?php elseif($item->time->TIME =='15:00-16:30'): ?>
                            4
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->time->REMARK); ?></td>
                        <td><?php echo e($item->classroom->NAME); ?></td>
                        <td><?php echo e($item->teacher->TITEL); ?> <?php echo e($item->teacher->FNAME); ?> <?php echo e($item->teacher->LNAME); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($active_hour)); ?>/<?php echo e(number_format($item->NUMBER_HOUR)); ?></td>
                        <td style="text-align: center"><?php echo e(number_format($item->NUMBER_HOUR - $active_hour)); ?>/<?php echo e(number_format($item->NUMBER_HOUR)); ?></td>
                        <?php if(auth()->guard('webstudent')->user()->role_id !=0): ?>
                        <td style="text-align: center"><a href="<?php echo e(route('student.teacherupclass', ['slug' => $item->TBID ])); ?>"><u>ບັນທຶກ</u></a></td>
                        <?php endif; ?>
                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/student/subject-list-component.blade.php ENDPATH**/ ?>