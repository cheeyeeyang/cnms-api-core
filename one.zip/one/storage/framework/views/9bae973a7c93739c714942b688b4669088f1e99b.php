<div>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
        </div>
        <div class="col-sm-6">
           <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('student.subject')); ?>">ໜ້າຫຼັກ</a></li>
                <li class="breadcrumb-item active">ປະເມີນອາຈານ</li>
            </ol>
        </div>
      </div>
    </div>
  </div>
    <div class="container-fluid">
      <div class="row">
        <!--customers -->
        <div class="col-md-12">
          <div class="card">
            <div class="card-header text-center">
               <h5><b>ຮ່າງປະເມີນການສອນຂອງອາຈານຄະນະວິທະຍາສາດທໍາມະຊາດ,ມະຫາວິທະຍາໄລແຫ່ງຊາດ <br>
               ປະຈໍາພາກຮຽນ <span style ="color:red"><?php if($this->semester ==1): ?>I <?php else: ?> II <?php endif; ?></span> ສົກສຶກສາ <span style="color:red"><?php echo e($this->acyear); ?></span> </b></h5>
            </div>
            <div class="card-body">
                <div class="row">
                     <h6> <b>•	ຄໍາແນະນໍາ:</b></h6> <br>
                     <p>      
                        -	ເພື່ອປະໂຫຍດໃນການປັບປຸງການຮຽນການສອນໃຫ້ມີຄຸນະພາບ ແລະ ປະສິດຕິຜົນດີເພີ່ມຂຶ້ນ ກະລຸນາຕອບ ແບບປະເມີນ ຕາມຄວາມເປັນຈິງຫຼາຍທີ່ສຸດ, ການຕອບແບບປະເມີນນີ້ຈະບໍ່ມີຜົນ ກະທົບຫຍັງຕໍ່ການຮຽນ ແລະ ການສອບເສັງຂອງນັກສຶກສາ. <br>
                        -	ກະລຸນາເລືອກ <input type="radio" checked> ໃສ່ຕາຕະລາງຄະແນນ. <br>
                        -	ກໍລະນີລາຍວິຊາທີ່ມີອາຈານສອນຫຼາຍຄົນ ແມ່ນໃຫ້ໃຊ້ໃບປະເມີນຄົນລະແຜ່ນ. 
                     </p>
                </div>
                <div class="row flex-column">
                     <h6><b>•	ຂໍ້ມູນທົ່ວໄປຂອງອາຈານສອນ:</b></h6>
                     <p>
                     &nbsp;&nbsp;ຊື່ ແລະ ນາມສະກຸນ: <span style="color:red"><?php echo e($this->teacher); ?></span><br>
                     &nbsp;&nbsp;ຊື່ວິຊາ: <span style="color:red"><?php echo e($this->subject); ?>(<?php echo e($this->classroomtype); ?>) </span>  ລະຫັດວິຊາ: <span style="color:red"><?php echo e($this->subject_id); ?></span>  ພາກວິຊາ: <span style="color:red"><?php echo e($this->department); ?></span>
                     </p>
                </div>
                <div class="row">
                     <h6><b>•	ຈໍານວນຄັ້ງທີ່ນັກສຶກສາຂາດຮຽນລາຍວິຊານີ້: <span style="color:red"><?php if(!empty($this->total_count_absent)): ?><?php echo e($this->count_absent); ?>/<?php echo e($this->total_count_absent); ?>ຄັ້ງ<?php endif; ?> <?php if($this->check_role_evaluation > 0): ?> (<?php echo e(number_format($this->check_role_evaluation)); ?>%) <?php endif; ?></span> </b></h6> 
                </div>
                <div class="row flex-column">
                     <h6><b>•	ຄວາມຄິດເຫັນ:</b></h6> 
                     <p>&nbsp;&nbsp;ຄະແນນ:  <b>5</b> ດີຫຼາຍ, <b>4</b> ດີ, <b>3</b> ປານກາງ, <b>2</b> ພໍໃຊ້, 1 ຕ້ອງປັບປຸງ, <b>0</b> ບໍ່ສາມາດປະເມີນ.</p>
                </div>
                <div class="table-responsive mt-2">
                    <table class="table table-bordered table-striped" style="white-space:nowrap;">
                         <thead>
                            <th style="text-align:center;">ລ/ດ</th>
                             <th>ລາຍການ</th>
                             <th style="text-align:center;">5</th>
                             <th style="text-align:center;">4</th>
                             <th style="text-align:center;">3</th>
                             <th style="text-align:center;">2</th>
                             <th style="text-align:center;">1</th>
                             <th style="text-align:center;">0</th>
                         </thead>
                         <tbody>
                             <?php 
                             $i = 1;
                             ?>
                             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php 
                               $check_evaluation = DB::table('evaluations')->where('QTID', $item->ID)->where('TBID', $this->TBID)->where('STDID', auth()->guard('webstudent')->user()->STDUSER)->where('ACYEAR', $this->acyear)->first();
                               $check_evaluation_already= DB::table('evaluations')->where('QTID', $item->ID)->where('TBID', $this->TBID)->where('STDID', auth()->guard('webstudent')->user()->STDUSER)->where('ACYEAR', $this->acyear)->where('STATUS', 1)->get();
                               $single_check_evaluation_already= DB::table('evaluations')->where('QTID', $item->ID)->where('TBID', $this->TBID)->where('STDID', auth()->guard('webstudent')->user()->STDUSER)->where('ACYEAR', $this->acyear)->where('STATUS', 1)->first();
                             ?>
                             <?php if($this->check_role_evaluation <= 30): ?>
                             <?php if($check_evaluation_already->count() > 0): ?>
                                <?php if($single_check_evaluation_already): ?>
                                 <tr>
                                     <td style="text-align:center;"><?php echo e($i++); ?></td>
                                     <td><?php echo e($item->QUESTION); ?></td>
                                     <?php if($single_check_evaluation_already->SCORE ==5): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                     <?php if($single_check_evaluation_already->SCORE ==4): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                     <?php if($single_check_evaluation_already->SCORE ==3): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                     <?php if($single_check_evaluation_already->SCORE ==2): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                     <?php if($single_check_evaluation_already->SCORE ==1): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                     <?php if($single_check_evaluation_already->SCORE ==0): ?>
                                       <td style="text-align:center;"><input type="radio" checked disabled></td>
                                     <?php else: ?>
                                     <td></td>
                                     <?php endif; ?>
                                </tr>
                                <?php endif; ?>
                             <?php else: ?>
                                <?php if($check_evaluation): ?>
                                <tr>
                                     <td style="text-align:center;"><?php echo e($i++); ?></td>
                                     <td><?php echo e($item->QUESTION); ?></td>
                                     <?php if($check_evaluation->SCORE ==5): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,5" wire:model="score">
                                     <?php endif; ?>
                                     <?php if($check_evaluation->SCORE ==4): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,4" wire:model="score">
                                     <?php endif; ?>
                                     <?php if($check_evaluation->SCORE ==3): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,3" wire:model="score">
                                     <?php endif; ?>
                                     <?php if($check_evaluation->SCORE ==2): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,2" wire:model="score">
                                     <?php endif; ?>
                                     <?php if($check_evaluation->SCORE ==1): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,1" wire:model="score">
                                     <?php endif; ?>
                                     <?php if($check_evaluation->SCORE ==0): ?>
                                       <td style="text-align:center;"><input type="radio" checked></td>
                                     <?php else: ?>
                                       <td style="text-align:center;"><input type="radio" wire:click="edit_clickselectedScore('<?php echo e($check_evaluation->QTID); ?>')"  value="<?php echo e($item->ID); ?>,0" wire:model="score">
                                     <?php endif; ?>
                                </tr>
                                <?php else: ?>
                                <tr>
                                     <td style="text-align:center;"><?php echo e($i++); ?></td>
                                     <td><?php echo e($item->QUESTION); ?></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,5" wire:model="score"></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,4" wire:model="score"></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,3" wire:model="score"></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,2" wire:model="score"></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,1" wire:model="score"></td>
                                     <td style="text-align:center;"><input type="radio" wire:click="clickselectedScore('<?php echo e($item->ID); ?>')"  value="<?php echo e($item->ID); ?>,0" wire:model="score"></td>
                                </tr>
                                <?php endif; ?>
                              <?php endif; ?>
                              <?php else: ?>
                              <tr>
                                     <td style="text-align:center;"><?php echo e($i++); ?></td>
                                     <td><?php echo e($item->QUESTION); ?></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                     <td></td>
                                </tr>
                              <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                     </table>
                </div>
                <?php if($this->check_role_evaluation <= 30): ?>
                <form>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">ຂໍ້ສະເໜີອື່ນໆ</label>
                                    <?php if($check_comment): ?>
                                       <textarea name="" id="" cols="30" wire:model="COMMENT" class="form-control" rows="4" disabled></textarea>
                                       <p class="text-left mt-1">
                                          <b>ໝາຍເຫດ:</b> <i class="fa fa-check-circle text-success"></i> <span class="text-success">ນັກສຶກສາປະເມີນລາຍວິຊານີ້ສໍາເລັດແລ້ວ.</span>
                                      </p>
                                    <?php else: ?>
                                    <textarea name="" id="" wire:model="COMMENT" cols="30" placeholder=".................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................................." class="form-control  <?php $__errorArgs = ['COMMENT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4"></textarea><br>
                                    <?php $__errorArgs = ['COMMENT'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color: red;" class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php if(!$check_comment): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <a href="#" wire:click="Saveevaluation" class="btn btn-primary btn-sm w-100">ປະເມີນ</a>
                            </div>
                        </div>
                        <?php endif; ?>
                </form>
                <?php else: ?>
                <p class="text-left">
                   <b>ໝາຍເຫດ:</b> ຖ້ານັກສຶກສາຂາດບໍ່ເກີນ 30% ຈຶ່ງສາມາດປະເມີນລາຍວິຊານີ້ໄດ້.
                </p>
                <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
</div><?php /**PATH C:\Ampps\apache\htdocs\MFNS\resources\views/livewire/frontend/student/evaluation-component.blade.php ENDPATH**/ ?>